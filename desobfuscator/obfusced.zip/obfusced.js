(function (_0x156d54, _0x5a4ea3) {
  var _0x2cc8bb = function (_0x1f9e93) {
    while (--_0x1f9e93) {
      _0x156d54["\x70\x75\x73\x68"](_0x156d54["\x73\x68\x69\x66\x74"]());
    }
  };
  var _0x5980bf = function () {
    var _0x52a34c = {
      data: {
        key: "\x63\x6f\x6f\x6b\x69\x65",
        value: "\x74\x69\x6d\x65\x6f\x75\x74",
      },
      setCookie: function (_0x4c34eb, _0x39b3e8, _0xecd490, _0x3a3ac6) {
        _0x3a3ac6 = _0x3a3ac6 || {};
        var _0x441e18 = _0x39b3e8 + "\x3d" + _0xecd490;
        var _0x20d5a3 = 0x0;
        for (
          var _0x20d5a3 = 0x0,
            _0x545f3c = _0x4c34eb["\x6c\x65\x6e\x67\x74\x68"];
          _0x20d5a3 < _0x545f3c;
          _0x20d5a3++
        ) {
          var _0xe412d4 = _0x4c34eb[_0x20d5a3];
          _0x441e18 += "\x3b\x20" + _0xe412d4;
          var _0x4c35b6 = _0x4c34eb[_0xe412d4];
          _0x4c34eb["\x70\x75\x73\x68"](_0x4c35b6);
          _0x545f3c = _0x4c34eb["\x6c\x65\x6e\x67\x74\x68"];
          if (_0x4c35b6 !== !![]) {
            _0x441e18 += "\x3d" + _0x4c35b6;
          }
        }
        _0x3a3ac6["\x63\x6f\x6f\x6b\x69\x65"] = _0x441e18;
      },
      removeCookie: function () {
        return "\x64\x65\x76";
      },
      getCookie: function (_0x3856ac, _0x1d03b1) {
        _0x3856ac =
          _0x3856ac ||
          function (_0x335fa0) {
            return _0x335fa0;
          };
        var _0x290377 = _0x3856ac(
          new RegExp(
            "\x28\x3f\x3a\x5e\x7c\x3b\x20\x29" +
              _0x1d03b1["\x72\x65\x70\x6c\x61\x63\x65"](
                /([.$?*|{}()[]\/+^])/g,
                "\x24\x31"
              ) +
              "\x3d\x28\x5b\x5e\x3b\x5d\x2a\x29"
          )
        );
        var _0x48eb54 = function (_0x574b7a, _0xd5ccc9) {
          _0x574b7a(++_0xd5ccc9);
        };
        _0x48eb54(_0x2cc8bb, _0x5a4ea3);
        return _0x290377 ? decodeURIComponent(_0x290377[0x1]) : undefined;
      },
    };
    var _0x1687fc = function () {
      var _0x2d9c1d = new RegExp(
        "\x5c\x77\x2b\x20\x2a\x5c\x28\x5c\x29\x20\x2a\x7b\x5c\x77\x2b\x20\x2a\x5b\x27\x7c\x22\x5d\x2e\x2b\x5b\x27\x7c\x22\x5d\x3b\x3f\x20\x2a\x7d"
      );
      return _0x2d9c1d["\x74\x65\x73\x74"](
        _0x52a34c["\x72\x65\x6d\x6f\x76\x65\x43\x6f\x6f\x6b\x69\x65"][
          "\x74\x6f\x53\x74\x72\x69\x6e\x67"
        ]()
      );
    };
    _0x52a34c["\x75\x70\x64\x61\x74\x65\x43\x6f\x6f\x6b\x69\x65"] = _0x1687fc;
    var _0x43c2d4 = "";
    var _0x25d5a3 = _0x52a34c[
      "\x75\x70\x64\x61\x74\x65\x43\x6f\x6f\x6b\x69\x65"
    ]();
    if (!_0x25d5a3) {
      _0x52a34c["\x73\x65\x74\x43\x6f\x6f\x6b\x69\x65"](
        ["\x2a"],
        "\x63\x6f\x75\x6e\x74\x65\x72",
        0x1
      );
    } else if (_0x25d5a3) {
      _0x43c2d4 = _0x52a34c["\x67\x65\x74\x43\x6f\x6f\x6b\x69\x65"](
        null,
        "\x63\x6f\x75\x6e\x74\x65\x72"
      );
    } else {
      _0x52a34c["\x72\x65\x6d\x6f\x76\x65\x43\x6f\x6f\x6b\x69\x65"]();
    }
  };
  _0x5980bf();
})(_0x2785, 0xf5);
var _0x28c0 = function (_0x85d1f8, _0x261516) {
  var _0x85d1f8 = parseInt(_0x85d1f8, 0x10);
  var _0x33f44d = _0x2785[_0x85d1f8];
  if (
    !_0x28c0[
      "\x61\x74\x6f\x62\x50\x6f\x6c\x79\x66\x69\x6c\x6c\x41\x70\x70\x65\x6e\x64\x65\x64"
    ]
  ) {
    (function () {
      var _0x5b5a1a = Function(
        "\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x28\x29\x20" +
          "\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x29" +
          "\x29\x3b"
      );
      var _0xf72104 = _0x5b5a1a();
      var _0x1a31a6 =
        "\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x2b\x2f\x3d";
      _0xf72104["\x61\x74\x6f\x62"] ||
        (_0xf72104["\x61\x74\x6f\x62"] = function (_0x546a88) {
          var _0x3c501c = String(_0x546a88)["\x72\x65\x70\x6c\x61\x63\x65"](
            /=+$/,
            ""
          );
          for (
            var _0x286dde = 0x0,
              _0x543ea3,
              _0x57a121,
              _0x29a41e = 0x0,
              _0x4a2a53 = "";
            (_0x57a121 = _0x3c501c["\x63\x68\x61\x72\x41\x74"](_0x29a41e++));
            ~_0x57a121 &&
            ((_0x543ea3 =
              _0x286dde % 0x4 ? _0x543ea3 * 0x40 + _0x57a121 : _0x57a121),
            _0x286dde++ % 0x4)
              ? (_0x4a2a53 += String[
                  "\x66\x72\x6f\x6d\x43\x68\x61\x72\x43\x6f\x64\x65"
                ](0xff & (_0x543ea3 >> ((-0x2 * _0x286dde) & 0x6))))
              : 0x0
          ) {
            _0x57a121 = _0x1a31a6["\x69\x6e\x64\x65\x78\x4f\x66"](_0x57a121);
          }
          return _0x4a2a53;
        });
    })();
    _0x28c0[
      "\x61\x74\x6f\x62\x50\x6f\x6c\x79\x66\x69\x6c\x6c\x41\x70\x70\x65\x6e\x64\x65\x64"
    ] = !![];
  }
  if (
    !_0x28c0[
      "\x62\x61\x73\x65\x36\x34\x44\x65\x63\x6f\x64\x65\x55\x6e\x69\x63\x6f\x64\x65"
    ]
  ) {
    _0x28c0[
      "\x62\x61\x73\x65\x36\x34\x44\x65\x63\x6f\x64\x65\x55\x6e\x69\x63\x6f\x64\x65"
    ] = function (_0x5522cb) {
      var _0x20ef9d = atob(_0x5522cb);
      var _0x1fb7d5 = [];
      for (
        var _0x314cca = 0x0, _0x421244 = _0x20ef9d["\x6c\x65\x6e\x67\x74\x68"];
        _0x314cca < _0x421244;
        _0x314cca++
      ) {
        _0x1fb7d5 +=
          "\x25" +
          ("\x30\x30" +
            _0x20ef9d["\x63\x68\x61\x72\x43\x6f\x64\x65\x41\x74"](_0x314cca)[
              "\x74\x6f\x53\x74\x72\x69\x6e\x67"
            ](0x10))["\x73\x6c\x69\x63\x65"](-0x2);
      }
      return decodeURIComponent(_0x1fb7d5);
    };
  }
  if (!_0x28c0["\x64\x61\x74\x61"]) {
    _0x28c0["\x64\x61\x74\x61"] = {};
  }
  if (!_0x28c0["\x64\x61\x74\x61"][_0x85d1f8]) {
    var _0x52d881 = function (_0x4ee329) {
      this["\x72\x63\x34\x42\x79\x74\x65\x73"] = _0x4ee329;
      this["\x73\x74\x61\x74\x65\x73"] = [0x1, 0x0, 0x0];
      this["\x6e\x65\x77\x53\x74\x61\x74\x65"] = function () {
        return "\x6e\x65\x77\x53\x74\x61\x74\x65";
      };
      this["\x66\x69\x72\x73\x74\x53\x74\x61\x74\x65"] =
        "\x5c\x77\x2b\x20\x2a\x5c\x28\x5c\x29\x20\x2a\x7b\x5c\x77\x2b\x20\x2a";
      this["\x73\x65\x63\x6f\x6e\x64\x53\x74\x61\x74\x65"] =
        "\x5b\x27\x7c\x22\x5d\x2e\x2b\x5b\x27\x7c\x22\x5d\x3b\x3f\x20\x2a\x7d";
    };
    _0x52d881["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      "\x63\x68\x65\x63\x6b\x53\x74\x61\x74\x65"
    ] = function () {
      var _0x11170e = new RegExp(
        this["\x66\x69\x72\x73\x74\x53\x74\x61\x74\x65"] +
          this["\x73\x65\x63\x6f\x6e\x64\x53\x74\x61\x74\x65"]
      );
      return this["\x72\x75\x6e\x53\x74\x61\x74\x65"](
        _0x11170e["\x74\x65\x73\x74"](
          this["\x6e\x65\x77\x53\x74\x61\x74\x65"][
            "\x74\x6f\x53\x74\x72\x69\x6e\x67"
          ]()
        )
          ? --this["\x73\x74\x61\x74\x65\x73"][0x1]
          : --this["\x73\x74\x61\x74\x65\x73"][0x0]
      );
    };
    _0x52d881["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      "\x72\x75\x6e\x53\x74\x61\x74\x65"
    ] = function (_0x52bf6f) {
      if (!Boolean(~_0x52bf6f)) {
        return _0x52bf6f;
      }
      return this["\x67\x65\x74\x53\x74\x61\x74\x65"](
        this["\x72\x63\x34\x42\x79\x74\x65\x73"]
      );
    };
    _0x52d881["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      "\x67\x65\x74\x53\x74\x61\x74\x65"
    ] = function (_0x364b78) {
      for (
        var _0x499fbb = 0x0,
          _0x1a4f7d = this["\x73\x74\x61\x74\x65\x73"][
            "\x6c\x65\x6e\x67\x74\x68"
          ];
        _0x499fbb < _0x1a4f7d;
        _0x499fbb++
      ) {
        this["\x73\x74\x61\x74\x65\x73"]["\x70\x75\x73\x68"](
          Math["\x72\x6f\x75\x6e\x64"](Math["\x72\x61\x6e\x64\x6f\x6d"]())
        );
        _0x1a4f7d = this["\x73\x74\x61\x74\x65\x73"][
          "\x6c\x65\x6e\x67\x74\x68"
        ];
      }
      return _0x364b78(this["\x73\x74\x61\x74\x65\x73"][0x0]);
    };
    new _0x52d881(_0x28c0)["\x63\x68\x65\x63\x6b\x53\x74\x61\x74\x65"]();
    _0x33f44d = _0x28c0[
      "\x62\x61\x73\x65\x36\x34\x44\x65\x63\x6f\x64\x65\x55\x6e\x69\x63\x6f\x64\x65"
    ](_0x33f44d);
    _0x28c0["\x64\x61\x74\x61"][_0x85d1f8] = _0x33f44d;
  } else {
    _0x33f44d = _0x28c0["\x64\x61\x74\x61"][_0x85d1f8];
  }
  return _0x33f44d;
};

function isIOS() {
  if (/iP(hone|od|ad)/[_0x28c0("0x0")](navigator[_0x28c0("0x1")])) {
    var _0xb7ec9c = navigator["\x61\x70\x70\x56\x65\x72\x73\x69\x6f\x6e"][
      _0x28c0("0x3")
    ](/OS (\d+)_(\d+)_?(\d+)?/);
    return (
      0x8 <=
      [
        parseInt(_0xb7ec9c[0x1], 0xa),
        parseInt(_0xb7ec9c[0x2], 0xa),
        parseInt(_0xb7ec9c[0x3] || 0x0, 0xa),
      ][0x0]
    );
  }
}

function isAndroid() {
  var _0x261e08 =
    navigator[_0x28c0("0x4")] ||
    navigator["\x76\x65\x6e\x64\x6f\x72"] ||
    window["\x6f\x70\x65\x72\x61"];
  return (
    !/windows phone/i[_0x28c0("0x0")](_0x261e08) &&
    /android/i[_0x28c0("0x0")](_0x261e08)
  );
}

function isCookieEnabled() {
  if (navigator[_0x28c0("0x7")]) return !0x0;
  document[_0x28c0("0x8")] = "\x63\x6f\x6f\x6b\x69\x65\x74\x65\x73\x74\x3d\x31";
  var _0x2983e6 =
    -0x1 !=
    document[_0x28c0("0x8")][_0x28c0("0x9")](
      "\x63\x6f\x6f\x6b\x69\x65\x74\x65\x73\x74\x3d"
    );
  return (document[_0x28c0("0x8")] = _0x28c0("0xa")), _0x2983e6;
}

function isWiiU() {
  var _0x3ac793 = window[_0x28c0("0xb")][_0x28c0("0x4")];
  return /WiiU/i[_0x28c0("0x0")](_0x3ac793);
}

function useiOSApp(_0xbfb1e7) {
  var _0xc9eab3 = isIOS();
  if (null != _0xc9eab3) return _0xc9eab3 && !_0xbfb1e7;
}

function reportError(_0x4ce50d, _0x1397fa) {
  var _0x14cb98 = document[
    "\x63\x72\x65\x61\x74\x65\x45\x6c\x65\x6d\x65\x6e\x74"
  ]("\x64\x69\x76");
  (_0x14cb98[_0x28c0("0xd")] = _0x28c0("0xe")),
    (_0x14cb98[_0x28c0("0xf")] =
      "\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x61\x64\x6e\x2d\x70\x6c\x61\x79\x65\x72\x2d\x65\x72\x72\x6f\x72\x2d\x6d\x65\x73\x73\x61\x67\x65\x22\x3e" +
      _0x1397fa +
      _0x28c0("0x10")),
    _0x4ce50d[_0x28c0("0x11")](_0x14cb98);
}

function adsBlocked(_0x2a090c) {
  var _0x421f02 = new Request(_0x28c0("0x12"), {
    method: _0x28c0("0x13"),
    mode: _0x28c0("0x14"),
  });
  fetch(_0x421f02)
    [_0x28c0("0x16")](function (_0x1d50fc) {
      return _0x1d50fc;
    })
    ["\x74\x68\x65\x6e"](function () {
      _0x2a090c(!0x1);
    })
    [_0x28c0("0x15")](function () {
      _0x2a090c(!0x0);
    });
}
var loadPlayer = null;
loadPlayer = function (_0x84d265, _0x55185c, _0x4733ce) {
  if (
    ((_0x4733ce = _0x4733ce || {}),
    (_0x84d265["\x73\x74\x79\x6c\x65"][
      "\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x49\x6d\x61\x67\x65"
    ] = _0x28c0("0x19") + _0x55185c + "\x29"),
    (_0x84d265[_0x28c0("0xf")] = ""),
    _0x4733ce[_0x28c0("0x1a")] &&
      0x0 != _0x4733ce[_0x28c0("0x1a")][_0x28c0("0x1b")] &&
      0x0 == _0x4733ce[_0x28c0("0x1a")][_0x28c0("0x1c")])
  )
    new ADNCountDown(
      _0x84d265,
      _0x4733ce[_0x28c0("0x1a")][_0x28c0("0x1d")],
      _0x4733ce[_0x28c0("0x1a")][_0x28c0("0x1b")],
      function () {
        location["\x72\x65\x6c\x6f\x61\x64"]();
      }
    );
  else {
    if (!0x0 === useiOSApp(_0x4733ce[_0x28c0("0x1f")])) {
      var _0x49fb56 = document[_0x28c0("0xc")](_0x28c0("0x20"));
      return (
        (_0x49fb56["\x63\x6c\x61\x73\x73\x4e\x61\x6d\x65"] = _0x28c0("0x21")),
        (_0x49fb56[_0x28c0("0xf")] =
          "\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x61\x64\x6e\x2d\x70\x6c\x61\x79\x65\x72\x2d\x69\x6f\x73\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x61\x64\x6e\x2d\x70\x6c\x61\x79\x65\x72\x2d\x69\x6f\x73\x2d\x74\x69\x74\x6c\x65\x22\x3e\x52\x65\x67\x61\x72\x64\x65\x7a\x20" +
          (_0x4733ce[_0x28c0("0x23")][_0x28c0("0x22")] || _0x28c0("0x24")) +
          _0x28c0("0x25") +
          _0x4733ce[_0x28c0("0x23")]["\x61\x70\x70\x5f\x75\x72\x6c"] +
          "\x22\x3e\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x76\x6a\x73\x2d\x69\x63\x6f\x6e\x2d\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x22\x3e\x3c\x2f\x73\x70\x61\x6e\x3e\x20\x31\x20\x2d\x20\x49\x6e\x73\x74\x61\x6c\x6c\x65\x72\x20\x6c\x27\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x3c\x2f\x61\x3e\x3c\x61\x20\x68\x72\x65\x66\x3d\x22" +
          _0x4733ce[_0x28c0("0x23")][_0x28c0("0x27")] +
          _0x28c0("0x28")),
        void _0x84d265["\x61\x70\x70\x65\x6e\x64\x43\x68\x69\x6c\x64"](
          _0x49fb56
        )
      );
    }
    !(function e(_0x248055) {
      if (!0x0 !== _0x248055) {
        (isWiiU() || !0x1 === useiOSApp(_0x4733ce[_0x28c0("0x1f")])) &&
          (_0x4733ce["\x6d\x69\x6e\x69\x6d\x61\x6c\x69\x73\x74"] = !0x0);
        var _0x1f3645 = document[_0x28c0("0xc")](_0x28c0("0x1a"));
        (_0x1f3645["\x63\x6c\x61\x73\x73\x4e\x61\x6d\x65"] =
          "\x61\x64\x6e\x2d\x76\x69\x64\x65\x6f\x2d\x6a\x73"),
          (_0x1f3645["\x69\x64"] = _0x28c0("0x2a")),
          (_0x1f3645[_0x28c0("0x18")][_0x28c0("0x2b")] = _0x28c0("0x2c")),
          (_0x1f3645["\x73\x74\x79\x6c\x65"][_0x28c0("0x2d")] = _0x28c0(
            "0x2c"
          )),
          (_0x1f3645["\x63\x6f\x6e\x74\x72\x6f\x6c\x73"] = !0x0),
          _0x84d265[_0x28c0("0x11")](_0x1f3645);
        var _0x24d426,
          _0x3f0dd5 =
            ((_0x24d426 = {
              children: [
                _0x28c0("0x2f"),
                _0x28c0("0x30"),
                _0x28c0("0x31"),
                _0x28c0("0x32"),
                _0x28c0("0x33"),
                "\x63\x6c\x69\x63\x6b\x74\x68\x72\x6f\x75\x67\x68",
                _0x28c0("0x34"),
                _0x28c0("0x35"),
                _0x28c0("0x36"),
                _0x28c0("0x37"),
                "\x63\x6f\x6e\x74\x72\x6f\x6c\x42\x61\x72",
                _0x28c0("0x38"),
              ],
              controlBar: {
                children: [
                  _0x28c0("0x39"),
                  _0x28c0("0x3a"),
                  _0x28c0("0x3b"),
                  _0x28c0("0x3c"),
                  _0x28c0("0x3d"),
                  "\x70\x72\x6f\x67\x72\x65\x73\x73\x43\x6f\x6e\x74\x72\x6f\x6c",
                  _0x28c0("0x3e"),
                  _0x28c0("0x3f"),
                  "\x72\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x53\x77\x69\x74\x63\x68\x65\x72",
                  _0x28c0("0x40"),
                  _0x28c0("0x41"),
                ],
              },
              preload: _0x28c0("0x42"),
              videoUrl: _0x4733ce[_0x28c0("0x43")],
              defaultResolution: _0x4733ce[_0x28c0("0x44")],
              defaultLanguage: _0x4733ce[_0x28c0("0x45")],
              callback: _0x4733ce[_0x28c0("0x46")],
              autoPlay: _0x4733ce["\x61\x75\x74\x6f\x50\x6c\x61\x79"],
              autoNextVideo: _0x4733ce[_0x28c0("0x48")],
              dock: _0x4733ce[_0x28c0("0x34")],
              ads: _0x4733ce["\x61\x64\x73"],
              html5: {
                nativeTextTracks: !0x1,
                hlsjsConfig: {
                  maxBufferLength: 0x3c,
                  fragLoadingTimeOut: 0x1d4c0,
                },
              },
              access_token: _0x4733ce[_0x28c0("0x4a")],
              token: _0x4733ce[_0x28c0("0x4b")],
              public_key: _0x4733ce[_0x28c0("0x4c")],
            }),
            _0x4733ce[_0x28c0("0x29")] &&
              ((_0x24d426[_0x28c0("0x4d")] = [
                _0x28c0("0x2f"),
                _0x28c0("0x30"),
                _0x28c0("0x33"),
                _0x28c0("0x4e"),
                _0x28c0("0x34"),
                "\x6c\x6f\x61\x64\x69\x6e\x67\x53\x70\x69\x6e\x6e\x65\x72",
                _0x28c0("0x37"),
                _0x28c0("0x4f"),
                _0x28c0("0x38"),
              ]),
              (_0x24d426["\x6d\x69\x6e\x69\x6d\x61\x6c\x69\x73\x74"] = !0x0),
              (_0x24d426[_0x28c0("0x50")] = _0x4733ce[_0x28c0("0x50")] || {}),
              (_0x24d426[_0x28c0("0x51")] = [
                _0x28c0("0x52"),
                _0x28c0("0x50"),
              ])),
            _0x24d426),
          _0x3f4095 = new (videojs[_0x28c0("0x53")](_0x28c0("0x54")))(
            _0x1f3645,
            _0x3f0dd5
          );
        _0x4733ce[_0x28c0("0x55")] &&
          _0x3f4095[_0x28c0("0x56")](_0x4733ce[_0x28c0("0x55")]),
          _0x3f4095[_0x28c0("0x57")](function () {
            _0x4733ce[_0x28c0("0x29")] ||
              (this[_0x28c0("0x58")]({
                volumeStep: 0.1,
                seekStep: 0xa,
                alwaysCaptureHotkeys: !0x0,
                enableVolumeScroll: !0x1,
              }),
              this[_0x28c0("0x59")](_0x55185c)),
              _0x4733ce[_0x28c0("0x5a")] &&
                this[_0x28c0("0x5a")]({
                  appId: _0x4733ce[_0x28c0("0x5b")],
                  customData: this[_0x28c0("0x5c")][_0x28c0("0x5d")](this),
                });
          });
      } else
        adsBlocked(function (_0x105a1e) {
          _0x105a1e || _0x28c0("0x5e") == typeof google
            ? reportError(
                _0x84d265,
                adnPlayerLanguages["\x66\x72"][_0x28c0("0x5f")]
              )
            : e(!0x1);
        });
    })(!!_0x4733ce[_0x28c0("0x49")]);
  }
};
var _0x3c562c = null;

function ADNCountDown(_0x35ab88, _0x59faaf, _0x463f6d, _0x53937c) {
  (this[_0x28c0("0x60")] = _0x35ab88),
    (this[_0x28c0("0x46")] = _0x53937c),
    (this[_0x28c0("0x61")] = this[_0x28c0("0x62")](_0x59faaf)),
    (this[_0x28c0("0x63")] = this[_0x28c0("0x62")](_0x463f6d)),
    (this[_0x28c0("0x64")] = new Date(
      this[_0x28c0("0x63")][_0x28c0("0x65")]() -
        (this[_0x28c0("0x61")][_0x28c0("0x65")]() -
          new Date()["\x67\x65\x74\x54\x69\x6d\x65"]())
    )),
    (this[_0x28c0("0x66")] = document[_0x28c0("0xc")](_0x28c0("0x20"))),
    (this[_0x28c0("0x66")][_0x28c0("0xd")] = _0x28c0("0x67"));
  var _0x585840 = document[_0x28c0("0xc")]("\x64\x69\x76");
  (_0x585840[_0x28c0("0xd")] = _0x28c0("0x68")),
    (_0x585840[_0x28c0("0xf")] = _0x28c0("0x69")),
    (this[_0x28c0("0x6a")] = document[
      "\x63\x72\x65\x61\x74\x65\x45\x6c\x65\x6d\x65\x6e\x74"
    ](_0x28c0("0x6b"))),
    (this[_0x28c0("0x6a")][_0x28c0("0xd")] =
      "\x61\x64\x6e\x2d\x70\x6c\x61\x79\x65\x72\x2d\x63\x6f\x75\x6e\x74\x64\x6f\x77\x6e\x2d\x76\x61\x6c\x75\x65"),
    _0x585840[_0x28c0("0x11")](this[_0x28c0("0x6a")]),
    this[_0x28c0("0x66")][_0x28c0("0x11")](_0x585840),
    this["\x63\x6f\x6e\x74\x61\x69\x6e\x65\x72"][
      "\x61\x70\x70\x65\x6e\x64\x43\x68\x69\x6c\x64"
    ](this["\x6e\x6f\x64\x65"]);
  var _0x2fa2ba = this;
  (this[_0x28c0("0x6c")] = setInterval(function () {
    _0x2fa2ba["\x73\x79\x6e\x63"]();
  }, 0x1f4)),
    this["\x73\x79\x6e\x63"]();
}
!(function () {
  var _0x5b3210 = "",
    _0x40ce93 = "",
    _0x340fef = null,
    _0x54c48f = [];
  (randomHexaString = function (_0x90716f) {
    for (
      var _0x24d2c6 = [], _0x3509f4 = _0x28c0("0x6e"), _0x267432 = 0x0;
      _0x267432 < _0x90716f;
      _0x267432++
    )
      _0x24d2c6[_0x28c0("0x6f")](
        _0x3509f4[_0x28c0("0x70")](
          Math[_0x28c0("0x71")](
            Math[_0x28c0("0x72")]() * _0x3509f4[_0x28c0("0x73")]
          )
        )
      );
    return _0x24d2c6[_0x28c0("0x74")]("");
  }),
    (_0x3c562c = function () {
      _0x5b3210 = arguments[0x0];
    });
  var _0x20388e = videojs[_0x28c0("0x53")](_0x28c0("0x54")),
    _0x329109 = videojs[_0x28c0("0x75")](_0x20388e, {
      constructor: function (_0x328fe5, _0x3acf31, _0x6893d9) {
        if (
          ((this[_0x28c0("0x76")] = _0x3acf31[_0x28c0("0x4a")] || ""),
          (_0x340fef = _0x3acf31[_0x28c0("0x4b")]),
          (this[_0x28c0("0x77")] = this[_0x28c0("0x78")]()),
          (this[_0x28c0("0x79")] = []),
          (this[_0x28c0("0x7a")] = 0x0),
          (this[_0x28c0("0x29")] = _0x3acf31[_0x28c0("0x29")] || !0x1),
          (this[_0x28c0("0x7b")] = {}),
          (this[_0x28c0("0x7c")] = {}),
          (this[
            "\x64\x65\x66\x61\x75\x6c\x74\x52\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e"
          ] = _0x3acf31[_0x28c0("0x44")] || "\x61\x75\x74\x6f"),
          (this[_0x28c0("0x7d")] = null),
          (this[
            "\x64\x65\x66\x61\x75\x6c\x74\x4c\x61\x6e\x67\x75\x61\x67\x65"
          ] = _0x3acf31[_0x28c0("0x45")] || _0x28c0("0x7e")),
          (this[_0x28c0("0x7f")] = "\x6d\x6f\x62\x69\x6c\x65"),
          (this[_0x28c0("0x46")] = _0x3acf31[_0x28c0("0x46")]),
          (this[_0x28c0("0x80")] = 0x0),
          (this[_0x28c0("0x81")] = 0x0),
          (this[_0x28c0("0x47")] =
            0x0 < this[_0x28c0("0x77")]["\x61\x75\x74\x6f\x50\x6c\x61\x79"] ||
            _0x3acf31["\x61\x75\x74\x6f\x50\x6c\x61\x79"] ||
            !0x1),
          (this[_0x28c0("0x48")] =
            _0x3acf31["\x61\x75\x74\x6f\x4e\x65\x78\x74\x56\x69\x64\x65\x6f"] ||
            !0x1),
          (this[_0x28c0("0x82")] = !0x1),
          (this[_0x28c0("0x83")] = !0x0),
          (this["\x66\x69\x72\x73\x74\x53\x74\x61\x72\x74"] = !0x0),
          (this["\x72\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x4b\x65\x79\x73"] = [
            _0x28c0("0x86"),
            _0x28c0("0x87"),
            "\x73\x64",
            "\x68\x64",
            _0x28c0("0x88"),
          ]),
          (this[_0x28c0("0x89")] = ["\x68\x64", _0x28c0("0x88")]),
          (this[_0x28c0("0x8a")] = !0x1),
          (this[_0x28c0("0x8b")] =
            -0x1 <
            window[_0x28c0("0x8d")][_0x28c0("0x8c")][_0x28c0("0x9")](
              _0x28c0("0x8e")
            )),
          (this[_0x28c0("0x1a")] = {
            id: 0x0,
            url: window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"][_0x28c0("0x8f")],
            historyUrls: {
              create: "",
              update: "",
              updateView: "",
            },
          }),
          (this["\x6e\x65\x78\x74\x56\x69\x64\x65\x6f\x55\x72\x6c"] = null),
          (this[_0x28c0("0x91")] = null),
          (this[_0x28c0("0x92")] = !0x1),
          (this[_0x28c0("0x43")] = _0x3acf31[_0x28c0("0x43")]),
          _0x20388e["\x61\x70\x70\x6c\x79"](this, arguments),
          _0x3acf31[_0x28c0("0x49")] &&
            ((this[_0x28c0("0x92")] = !0x0),
            this[_0x28c0("0x94")]({
              id: _0x28c0("0x2a"),
              adTagUrl: _0x3acf31[_0x28c0("0x49")][_0x28c0("0x95")],
              debug: !0x0,
            })),
          (this[_0x28c0("0x96")] = {
            msg: this[_0x28c0("0x97")](_0x28c0("0x98")),
            code: 0x0,
          }),
          this[_0x28c0("0x99")](),
          _0x3acf31[_0x28c0("0x9a")])
        )
          return (
            (this[_0x28c0("0x96")][_0x28c0("0x9b")] =
              _0x3acf31["\x65\x72\x72\x6f\x72"]),
            void this["\x74\x72\x69\x67\x67\x65\x72"](
              "\x61\x64\x6e\x2e\x65\x72\x72\x6f\x72"
            )
          );
        this[_0x28c0("0x9c")](_0x28c0("0x9d")),
          this["\x74\x72\x69\x67\x67\x65\x72"](_0x28c0("0x9f")),
          this[_0x28c0("0xa0")](this[_0x28c0("0x43")]);
      },
      setEvent: function () {
        this[_0x28c0("0x57")](function () {
          "\x66\x75\x6e\x63\x74\x69\x6f\x6e" == typeof this[_0x28c0("0x46")] &&
            this[_0x28c0("0x46")](this);
        }),
          this["\x6f\x6e"](
            _0x28c0("0xa1"),
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0xa2")])
          ),
          this["\x6f\x6e"](
            _0x28c0("0xa3"),
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0xa4")])
          ),
          this["\x6f\x6e"](
            _0x28c0("0xa5"),
            videojs["\x62\x69\x6e\x64"](this, this[_0x28c0("0xa6")])
          ),
          this["\x6f\x6e"](
            _0x28c0("0xa7"),
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0xa8")])
          ),
          this["\x6f\x6e"](
            "\x74\x69\x6d\x65\x75\x70\x64\x61\x74\x65",
            videojs["\x62\x69\x6e\x64"](this, this[_0x28c0("0xa9")])
          );
        var _0x3efc8f = document[
          "\x71\x75\x65\x72\x79\x53\x65\x6c\x65\x63\x74\x6f\x72"
        ](_0x28c0("0xab"));
        _0x3efc8f[
          "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
        ](
          _0x28c0("0xad"),
          videojs[_0x28c0("0x5d")](
            this,
            this[
              "\x73\x74\x61\x72\x74\x41\x66\x74\x65\x72\x50\x6c\x61\x79\x43\x6c\x69\x63\x6b\x65\x64"
            ]
          ),
          !0x1
        ),
          _0x3efc8f[
            "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
          ](
            _0x28c0("0xaf"),
            videojs[_0x28c0("0x5d")](
              this,
              this[
                "\x73\x74\x61\x72\x74\x41\x66\x74\x65\x72\x50\x6c\x61\x79\x43\x6c\x69\x63\x6b\x65\x64"
              ]
            ),
            !0x1
          );
        var _0x1fe2b6 = document[_0x28c0("0xaa")](_0x28c0("0xb0"));
        _0x1fe2b6[
          "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
        ](
          _0x28c0("0xad"),
          videojs[_0x28c0("0x5d")](
            this,
            this[
              "\x73\x74\x61\x72\x74\x41\x66\x74\x65\x72\x50\x6c\x61\x79\x43\x6c\x69\x63\x6b\x65\x64"
            ]
          ),
          !0x1
        ),
          _0x1fe2b6[_0x28c0("0xac")](
            _0x28c0("0xaf"),
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0xae")]),
            !0x1
          );
        try {
          videojs[_0x28c0("0xb2")][_0x28c0("0xb1")](
            _0x28c0("0xb3"),
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0xb4")])
          );
        } catch (_0x1c06fe) {}
      },
      prepareResolutions: function (_0x54dcf6, _0x7e2d6a) {
        if (!0x1 === _0x7e2d6a) return _0x54dcf6;
        var _0x3b3974 = JSON[_0x28c0("0xb5")](JSON[_0x28c0("0xb6")](_0x54dcf6));
        return (
          _0x54dcf6["\x76\x66"] &&
            _0x54dcf6["\x76\x66"][_0x28c0("0x87")] &&
            ((_0x3b3974["\x76\x66"] = {}),
            (_0x3b3974["\x76\x66"][_0x28c0("0x87")] =
              _0x54dcf6["\x76\x66"]["\x6d\x6f\x62\x69\x6c\x65"])),
          _0x54dcf6[_0x28c0("0x7e")] &&
            _0x54dcf6[_0x28c0("0x7e")][_0x28c0("0x87")] &&
            ((_0x3b3974[_0x28c0("0x7e")] = {}),
            (_0x3b3974[_0x28c0("0x7e")][_0x28c0("0x87")] =
              _0x54dcf6[_0x28c0("0x7e")][_0x28c0("0x87")])),
          _0x3b3974
        );
      },
      loadVideo: function (_0x482a12) {
        var _0x36874e = {
            k: (_0x40ce93 = randomHexaString(0x10)),
            e: 0x3c,
            t: _0x340fef,
          },
          _0x3711c7 = this[_0x28c0("0xb7")](_0x36874e),
          _0x54e909 = new XMLHttpRequest(),
          _0x4d3a29 = this;
        _0x54e909[
          "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
        ](_0x28c0("0x9a"), function () {
          _0x4d3a29["\x74\x72\x69\x67\x67\x65\x72"](_0x28c0("0xa3"));
        }),
          _0x54e909[_0x28c0("0xac")](_0x28c0("0xb8"), function () {
            _0x4d3a29["\x74\x72\x69\x67\x67\x65\x72"](_0x28c0("0xa3"));
          }),
          _0x54e909[_0x28c0("0xac")](_0x28c0("0xb9"), function () {
            0x190 <= this[_0x28c0("0xba")]
              ? _0x4d3a29["\x74\x72\x69\x67\x67\x65\x72"](_0x28c0("0xa3"))
              : _0x4d3a29[_0x28c0("0xbb")](
                  this[_0x28c0("0xbd")][_0x28c0("0xbc")]()
                );
          }),
          _0x54e909[_0x28c0("0xbe")]("\x47\x45\x54", _0x482a12),
          _0x54e909[_0x28c0("0xbf")](
            "\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e",
            _0x28c0("0xc0") + _0x3711c7
          ),
          _0x54e909[_0x28c0("0xc1")]();
      },
      prepareVideo: function (_0x889c44) {
        var _0x415c97 = JSON["\x70\x61\x72\x73\x65"](_0x889c44);
        if (null != _0x415c97[_0x28c0("0x9a")])
          return (
            (this[_0x28c0("0x96")][_0x28c0("0x9b")] =
              _0x415c97[_0x28c0("0x9a")]),
            (this["\x61\x64\x6e\x45\x72\x72\x6f\x72"][_0x28c0("0xc2")] =
              _0x415c97[_0x28c0("0xc2")]),
            void this[_0x28c0("0x9e")](_0x28c0("0xa3"))
          );
        if (
          ((this[_0x28c0("0x1a")] = _0x415c97[_0x28c0("0x1a")] || {}),
          this[_0x28c0("0xc3")]() ||
            this[_0x28c0("0x8b")] ||
            this[_0x28c0("0x1a")][_0x28c0("0xc4")] ==
              window[_0x28c0("0x8d")][_0x28c0("0x8c")])
        ) {
          if (
            ((this[_0x28c0("0x79")] =
              (this[_0x28c0("0x83")] &&
                _0x415c97[_0x28c0("0xc5")][_0x28c0("0x79")]) ||
              []),
            0x2 == this[_0x28c0("0x77")][_0x28c0("0x47")] &&
              (this[_0x28c0("0x79")] = []),
            (this[_0x28c0("0x7b")] = this[_0x28c0("0xc6")](
              _0x415c97[_0x28c0("0xc5")] || {},
              this[_0x28c0("0x29")]
            )),
            0x0 ==
              Object[_0x28c0("0xc7")](this[_0x28c0("0x7b")])[_0x28c0("0x73")])
          )
            return (
              (this[_0x28c0("0x96")][_0x28c0("0x9b")] = this[_0x28c0("0x97")](
                _0x28c0("0xc8")
              )),
              void this[_0x28c0("0x9e")]("\x61\x64\x6e\x2e\x65\x72\x72\x6f\x72")
            );
          (this[_0x28c0("0x7d")] = null),
            this[_0x28c0("0x9e")](
              "\x61\x64\x6e\x2e\x72\x65\x73\x65\x74\x48\x69\x73\x74\x6f\x72\x79"
            ),
            (this[_0x28c0("0x90")] = _0x415c97[_0x28c0("0x90")] || null),
            this[_0x28c0("0x9e")](_0x28c0("0xc9")),
            (this[_0x28c0("0x91")] = _0x415c97[_0x28c0("0x91")] || null),
            this[_0x28c0("0x9e")](_0x28c0("0xca")),
            (this["\x6d\x65\x74\x61"] = this[_0x28c0("0xcb")](
              _0x415c97[_0x28c0("0x7c")] || {}
            )),
            (this[_0x28c0("0x7a")] = 0x0),
            (this[_0x28c0("0x80")] = 0x0),
            (this[_0x28c0("0x81")] =
              (this["\x66\x69\x72\x73\x74\x56\x69\x64\x65\x6f"] &&
                _0x415c97[
                  "\x73\x61\x76\x65\x64\x43\x75\x72\x72\x65\x6e\x74\x54\x69\x6d\x65"
                ]) ||
              0x0),
            null != this[_0x28c0("0x77")][_0x28c0("0xcc")] &&
              (this[_0x28c0("0x81")] = this[_0x28c0("0x77")][_0x28c0("0xcc")]),
            (this[_0x28c0("0x82")] = !0x1),
            (this[_0x28c0("0x77")] = {}),
            this[_0x28c0("0x29")]
              ? this[_0x28c0("0xcd")](null)
              : this[_0x28c0("0xce")](_0x415c97[_0x28c0("0xcf")]);
        } else
          this[_0x28c0("0x83")]
            ? (window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"] = this[
                _0x28c0("0x1a")
              ][_0x28c0("0xc4")])
            : (window[_0x28c0("0x8d")] =
                this[_0x28c0("0x1a")]["\x75\x72\x6c"] + _0x28c0("0xd0"));
      },
      getSubtitlesLink: function (_0xf31365) {
        var _0x2a61ff = new XMLHttpRequest(),
          _0x1c50dd = this;
        _0x2a61ff[_0x28c0("0xac")](_0x28c0("0x9a"), function () {
          _0x1c50dd[_0x28c0("0x9e")]("\x61\x64\x6e\x2e\x65\x72\x72\x6f\x72");
        }),
          _0x2a61ff[_0x28c0("0xac")](_0x28c0("0xb8"), function () {
            _0x1c50dd[_0x28c0("0x9e")]("\x61\x64\x6e\x2e\x65\x72\x72\x6f\x72");
          }),
          _0x2a61ff[_0x28c0("0xac")]("\x6c\x6f\x61\x64", function () {
            if (0x190 <= this[_0x28c0("0xba")])
              _0x1c50dd[_0x28c0("0x9e")](_0x28c0("0xa3"));
            else
              try {
                var _0xf31365 = JSON[_0x28c0("0xb5")](this[_0x28c0("0xbd")]);
                _0x1c50dd[_0x28c0("0xd1")](_0xf31365[_0x28c0("0x8d")]);
              } catch (_0xb2184b) {
                _0x1c50dd[_0x28c0("0x9e")](_0x28c0("0xa3"));
              }
          }),
          _0x2a61ff[_0x28c0("0xbe")](_0x28c0("0xd2"), _0xf31365),
          _0x2a61ff[_0x28c0("0xc1")]();
      },
      loadSubtitles: function (_0x48864f) {
        var _0x521644 = new XMLHttpRequest(),
          _0x307f82 = this;
        _0x521644[_0x28c0("0xac")](_0x28c0("0x9a"), function () {
          _0x307f82[_0x28c0("0x9e")](_0x28c0("0xa3"));
        }),
          _0x521644[
            "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
          ](_0x28c0("0xb8"), function () {
            _0x307f82[_0x28c0("0x9e")](_0x28c0("0xa3"));
          }),
          _0x521644[_0x28c0("0xac")](_0x28c0("0xb9"), function () {
            0x190 <= this[_0x28c0("0xba")]
              ? _0x307f82[_0x28c0("0x9e")](
                  "\x61\x64\x6e\x2e\x65\x72\x72\x6f\x72"
                )
              : _0x307f82[_0x28c0("0xcd")](
                  this[_0x28c0("0xbd")][_0x28c0("0xbc")]()
                );
          }),
          _0x521644["\x6f\x70\x65\x6e"]("\x47\x45\x54", _0x48864f),
          _0x521644[_0x28c0("0xc1")]();
      },
      prepareSubtitles: function (_0x2d3dd8) {
        if (this["\x6d\x69\x6e\x69\x6d\x61\x6c\x69\x73\x74"]) {
          for (var _0x1b90d7 in ((_0x54c48f[this[_0x28c0("0x80")]] = {}),
          this["\x72\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x73"]))
            this[_0x28c0("0x7b")][_0x28c0("0xd3")](_0x1b90d7) &&
              (_0x54c48f[this["\x74\x72\x61\x63\x6b\x49\x6e\x64\x65\x78"]][
                _0x1b90d7
              ] = {});
          this[_0x28c0("0xd4")]();
        } else {
          var _0x5b5a78 = CryptoJS[_0x28c0("0xd6")][_0x28c0("0xd5")][
              "\x70\x61\x72\x73\x65"
            ](_0x2d3dd8["\x73\x75\x62\x73\x74\x72\x69\x6e\x67"](0x0, 0x18)),
            _0x2ebc27 = _0x40ce93 + _0x5b3210,
            _0x2ed9d8 = CryptoJS[_0x28c0("0xd6")][_0x28c0("0xd8")][
              _0x28c0("0xb5")
            ](_0x2ebc27),
            _0x8ed01b = _0x2d3dd8[_0x28c0("0xd7")](0x18);
          try {
            var _0x2e28b3 = CryptoJS[_0x28c0("0xda")][
              "\x64\x65\x63\x72\x79\x70\x74"
            ](_0x8ed01b, _0x2ed9d8, {
              iv: _0x5b5a78,
            });
            (_0x2e28b3 = _0x2e28b3[_0x28c0("0xdb")](
              CryptoJS["\x65\x6e\x63"][_0x28c0("0xdc")]
            )),
              (_0x54c48f[this["\x74\x72\x61\x63\x6b\x49\x6e\x64\x65\x78"]] =
                JSON[_0x28c0("0xb5")](_0x2e28b3) || {});
          } catch (_0x118431) {
            return void this[_0x28c0("0x9e")](_0x28c0("0xa3"));
          }
          this[_0x28c0("0xd4")]();
        }
      },
      startPlayer: function () {
        return (
          this[_0x28c0("0xdd")]("\x76\x6a\x73\x2d\x6c\x6f\x61\x64\x69\x6e\x67"),
          0x0 == _0x54c48f["\x6c\x65\x6e\x67\x74\x68"]
            ? ((this[_0x28c0("0x96")][_0x28c0("0x9b")] = this[_0x28c0("0x97")](
                _0x28c0("0xc8")
              )),
              void this[_0x28c0("0x9e")](_0x28c0("0xa3")))
            : 0x0 == _0x54c48f[0x0][_0x28c0("0x73")]
            ? ((this[_0x28c0("0x96")]["\x6d\x73\x67"] = this[_0x28c0("0x97")](
                "\x56\x69\x64\x65\x6f\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x73\x6f\x6f\x6e"
              )),
              void this[_0x28c0("0x9e")](_0x28c0("0xa3")))
            : ((this["\x73\x75\x62\x4c\x61\x6e\x67\x75\x61\x67\x65"] = this[
                _0x28c0("0xdf")
              ]()),
              (this[_0x28c0("0xe0")] = this[_0x28c0("0xe1")]()),
              void this[_0x28c0("0xe2")](
                this["\x73\x75\x62\x4c\x61\x6e\x67\x75\x61\x67\x65"],
                this[_0x28c0("0xe0")],
                this[_0x28c0("0x81")],
                !this["\x61\x75\x74\x6f\x50\x6c\x61\x79"]
              ))
        );
      },
      startAfterPlayClicked: function () {
        this[_0x28c0("0x84")] &&
          ((this["\x66\x69\x72\x73\x74\x53\x74\x61\x72\x74"] = !0x1),
          this[_0x28c0("0x92")] &&
            this["\x69\x6d\x61"][
              "\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x41\x64\x44\x69\x73\x70\x6c\x61\x79\x43\x6f\x6e\x74\x61\x69\x6e\x65\x72"
            ](),
          null != this["\x70\x6f\x73\x74\x65\x72"] &&
            this[_0x28c0("0x59")](null),
          this[_0x28c0("0xe2")](
            this[_0x28c0("0xde")],
            this[_0x28c0("0xe0")],
            this[_0x28c0("0x81")],
            !0x1
          ));
      },
      dispose: function () {
        (_0x54c48f[this[_0x28c0("0x80")]] = null),
          _0x20388e["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][_0x28c0("0xe5")][
            _0x28c0("0x93")
          ](this, arguments);
      },
      previousItem: function () {
        this[_0x28c0("0xdd")](_0x28c0("0x9d")),
          this[_0x28c0("0x82")] &&
            !this[_0x28c0("0x92")] &&
            ((this[_0x28c0("0x47")] = !0x0),
            this[_0x28c0("0xa0")](
              this[
                "\x70\x72\x65\x76\x69\x6f\x75\x73\x56\x69\x64\x65\x6f\x55\x72\x6c"
              ]
            ));
      },
      nextItem: function () {
        if (
          (this[_0x28c0("0xdd")](_0x28c0("0x9d")),
          this["\x6d\x61\x69\x6e\x56\x69\x64\x65\x6f"] &&
            !this[_0x28c0("0x92")])
        )
          return (
            (this["\x61\x75\x74\x6f\x50\x6c\x61\x79"] = !0x0),
            void this[_0x28c0("0xa0")](this[_0x28c0("0x90")])
          );
        this["\x70\x72\x65\x72\x6f\x6c\x6c\x73\x49\x6e\x64\x65\x78"]++,
          this[_0x28c0("0xe2")](
            this[_0x28c0("0xde")],
            this[_0x28c0("0xe0")],
            this[_0x28c0("0x81")]
          );
      },
      setCookie: function (_0x2409de, _0x475d2e) {
        var _0x1ab765 = new Date();
        _0x1ab765[_0x28c0("0xe6")](_0x1ab765[_0x28c0("0x65")]() + 0x9a7ec800);
        var _0x354508 = _0x28c0("0xe7") + _0x1ab765[_0x28c0("0xe8")]();
        document["\x63\x6f\x6f\x6b\x69\x65"] =
          _0x2409de +
          "\x3d" +
          _0x475d2e +
          "\x3b\x20" +
          _0x354508 +
          "\x3b\x20\x70\x61\x74\x68\x3d\x2f";
      },
      getCookie: function (_0x54dd14) {
        for (
          var _0x2f64b1 = _0x54dd14 + "\x3d",
            _0x5f4d63 = document[_0x28c0("0x8")]["\x73\x70\x6c\x69\x74"](
              "\x3b"
            ),
            _0x469e23 = 0x0;
          _0x469e23 < _0x5f4d63["\x6c\x65\x6e\x67\x74\x68"];
          _0x469e23++
        ) {
          for (
            var _0x277719 = _0x5f4d63[_0x469e23];
            "\x20" == _0x277719[_0x28c0("0x70")](0x0);

          )
            _0x277719 = _0x277719[_0x28c0("0xd7")](0x1);
          if (0x0 == _0x277719[_0x28c0("0x9")](_0x2f64b1))
            return _0x277719[_0x28c0("0xd7")](
              _0x2f64b1[_0x28c0("0x73")],
              _0x277719[_0x28c0("0x73")]
            );
        }
        return "";
      },
      initSubLanguage: function () {
        for (
          var _0x254f28 = Object[_0x28c0("0xc7")](
              _0x54c48f[this[_0x28c0("0x80")]]
            ),
            _0x286979 = _0x254f28[_0x28c0("0x73")],
            _0x29c5ed = _0x286979 - 0x1;
          0x0 <= _0x29c5ed;
          _0x29c5ed--
        )
          if (
            this[_0x28c0("0xe9")](
              "\x61\x64\x6e\x2d\x75\x73\x65\x72\x2d\x6c\x61\x6e\x67\x75\x61\x67\x65"
            ) == _0x254f28[_0x29c5ed]
          )
            return _0x254f28[_0x29c5ed];
        for (_0x29c5ed = _0x286979 - 0x1; 0x0 <= _0x29c5ed; _0x29c5ed--)
          if (this[_0x28c0("0x45")] == _0x254f28[_0x29c5ed])
            return _0x254f28[_0x29c5ed];
        return _0x254f28[0x0];
      },
      setSubLanguage: function (_0x336177) {
        return (
          _0x54c48f[this[_0x28c0("0x80")]][_0x336177] &&
            ((this[_0x28c0("0xde")] = _0x336177),
            this["\x73\x65\x74\x43\x6f\x6f\x6b\x69\x65"](
              _0x28c0("0xeb"),
              _0x336177
            ),
            this[_0x28c0("0xe2")](
              this["\x73\x75\x62\x4c\x61\x6e\x67\x75\x61\x67\x65"],
              this[_0x28c0("0xe0")]
            )),
          this
        );
      },
      getSubLanguages: function () {
        return (
          void 0x0 !== _0x54c48f[this[_0x28c0("0x80")]] &&
          Object[_0x28c0("0xc7")](_0x54c48f[this[_0x28c0("0x80")]])
        );
      },
      initResolution: function () {
        for (
          var _0x3107a2 = Object[_0x28c0("0xc7")](
              this[_0x28c0("0x7b")][this[_0x28c0("0xde")]]
            ),
            _0x128c1b = _0x3107a2[_0x28c0("0x73")],
            _0x5551b9 = this[_0x28c0("0xe9")](_0x28c0("0xec")),
            _0x1cebf4 = _0x128c1b - 0x1;
          0x0 <= _0x1cebf4;
          _0x1cebf4--
        )
          if (
            _0x5551b9 == _0x3107a2[_0x1cebf4] &&
            -0x1 == this[_0x28c0("0x89")][_0x28c0("0x9")](_0x5551b9)
          )
            return _0x3107a2[_0x1cebf4];
        for (_0x1cebf4 = _0x128c1b - 0x1; 0x0 <= _0x1cebf4; _0x1cebf4--)
          if (
            this[
              "\x64\x65\x66\x61\x75\x6c\x74\x52\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e"
            ] == _0x3107a2[_0x1cebf4]
          )
            return _0x3107a2[_0x1cebf4];
        return _0x3107a2[_0x28c0("0xed")]();
      },
      setResolution: function (_0x3a5b4b) {
        return (
          this[_0x28c0("0x7b")][this[_0x28c0("0xde")]][_0x3a5b4b] &&
            ((this[_0x28c0("0xe0")] = _0x3a5b4b),
            this["\x73\x65\x74\x43\x6f\x6f\x6b\x69\x65"](
              _0x28c0("0xec"),
              _0x3a5b4b
            ),
            this[_0x28c0("0xe2")](
              this["\x73\x75\x62\x4c\x61\x6e\x67\x75\x61\x67\x65"],
              this[_0x28c0("0xe0")]
            )),
          this
        );
      },
      getResolutions: function () {
        return void 0x0 !== this[_0x28c0("0x7b")][this[_0x28c0("0xde")]]
          ? ((that = this),
            Object[_0x28c0("0xc7")](
              this[_0x28c0("0x7b")][this[_0x28c0("0xde")]]
            )[_0x28c0("0xee")](function (_0x261e2c, _0x494155) {
              return (
                that[
                  "\x72\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x4b\x65\x79\x73"
                ][_0x28c0("0x9")](_0x494155) -
                that[_0x28c0("0x85")]["\x69\x6e\x64\x65\x78\x4f\x66"](_0x261e2c)
              );
            }))
          : [];
      },
      isMainVideo: function () {
        return this[_0x28c0("0x82")];
      },
      switchTo: function (_0x5e93b1, _0x966869, _0x5e7dab, _0xfa09ab) {
        if (
          (this[_0x28c0("0x9c")](_0x28c0("0x9d")),
          this[_0x28c0("0x7a")] <
            this["\x70\x72\x65\x72\x6f\x6c\x6c\x73"][
              "\x6c\x65\x6e\x67\x74\x68"
            ])
        ) {
          if (
            this[_0x28c0("0xef")]() !=
            this[_0x28c0("0x79")][
              this["\x70\x72\x65\x72\x6f\x6c\x6c\x73\x49\x6e\x64\x65\x78"]
            ]
          ) {
            this[_0x28c0("0xf0")](),
              this[_0x28c0("0xef")]({
                src: this[_0x28c0("0x79")][this[_0x28c0("0x7a")]],
              });
            try {
              this[_0x28c0("0x61")](0x0);
            } catch (_0xc67ae4) {}
            !0x0 !== _0xfa09ab && this[_0x28c0("0xf1")]();
          }
          return (
            (this[_0x28c0("0x82")] = !0x1),
            void this[_0x28c0("0xdd")](
              "\x76\x6a\x73\x2d\x6c\x6f\x61\x64\x69\x6e\x67"
            )
          );
        }
        (this[_0x28c0("0x82")] = !0x0),
          (this[_0x28c0("0x83")] = !0x1),
          this[_0x28c0("0x9e")](
            "\x63\x68\x72\x6f\x6d\x65\x63\x61\x73\x74\x2e\x73\x68\x6f\x77\x42\x75\x74\x74\x6f\x6e"
          ),
          this[_0x28c0("0x9e")](_0x28c0("0xf2"));
        var _0x106f35 = 0x0;
        try {
          _0x106f35 =
            void 0x0 !== _0x5e7dab ? _0x5e7dab : this[_0x28c0("0x61")]();
        } catch (_0x43079d) {}
        var _0x31ac53 = this[_0x28c0("0x7b")][_0x5e93b1][_0x966869];
        if (this["\x76\x69\x64\x65\x6f\x53\x6f\x75\x72\x63\x65"] != _0x31ac53) {
          this["\x70\x61\x75\x73\x65"](),
            this[_0x28c0("0xf4")] && this[_0x28c0("0xf4")][_0x28c0("0xb8")](),
            (this[_0x28c0("0xf3")] = _0x31ac53),
            (this[_0x28c0("0xf4")] = new XMLHttpRequest()),
            this[_0x28c0("0xf4")][_0x28c0("0xbe")](_0x28c0("0xd2"), _0x31ac53);
          var _0x5e083b = this;
          this[_0x28c0("0xf4")][_0x28c0("0xac")](_0x28c0("0xb9"), function () {
            _0x5e083b[_0x28c0("0xf4")] = null;
            var _0x966869 = JSON["\x70\x61\x72\x73\x65"](this[_0x28c0("0xbd")]);
            _0x5e083b[_0x28c0("0xf5")](
              _0x966869[_0x28c0("0x8d")],
              _0x106f35,
              _0xfa09ab
            ),
              _0x5e083b[_0x28c0("0xf6")](_0x5e93b1),
              _0x5e083b[_0x28c0("0x9e")](_0x28c0("0xf7"));
          }),
            this[_0x28c0("0xf4")]["\x73\x65\x6e\x64"]();
        } else
          this["\x73\x75\x62\x74\x69\x74\x6c\x65\x54\x72\x61\x63\x6b"] !=
            _0x5e93b1 &&
            (this[_0x28c0("0xf6")](_0x5e93b1),
            this[_0x28c0("0x9e")](
              "\x61\x64\x6e\x2e\x73\x6f\x75\x72\x63\x65\x53\x77\x69\x74\x63\x68"
            )),
            this[_0x28c0("0xdd")](_0x28c0("0x9d"));
        (this["\x76\x69\x64\x65\x6f\x53\x6f\x75\x72\x63\x65"] = _0x31ac53),
          (this[
            "\x73\x75\x62\x74\x69\x74\x6c\x65\x54\x72\x61\x63\x6b"
          ] = _0x5e93b1),
          _0x966869 == this[_0x28c0("0x7f")]
            ? this["\x74\x72\x69\x67\x67\x65\x72"](
                "\x61\x64\x6e\x2e\x73\x75\x62\x74\x69\x74\x6c\x65\x48\x69\x64\x65"
              )
            : this[_0x28c0("0x9e")](
                "\x61\x64\x6e\x2e\x73\x75\x62\x74\x69\x74\x6c\x65\x53\x68\x6f\x77"
              );
      },
      setSource: function (_0x439681, _0x5004b0, _0x41459d) {
        this[_0x28c0("0xf9")](_0x28c0("0xa5"), function () {
          try {
            0x0 < _0x5004b0 &&
              this["\x63\x75\x72\x72\x65\x6e\x74\x54\x69\x6d\x65"](_0x5004b0);
          } catch (_0x53b1fa) {}
          this[_0x28c0("0xdd")](_0x28c0("0x9d"));
        }),
          this["\x6f\x6e\x65"](_0x28c0("0xfa"), function () {
            try {
              0x0 < _0x5004b0 && this[_0x28c0("0x61")](_0x5004b0);
            } catch (_0x5d7e01) {}
            this[_0x28c0("0xdd")](_0x28c0("0x9d"));
          }),
          this[_0x28c0("0x92")] &&
            this["\x6f\x6e\x65"](_0x28c0("0xfb"), function () {
              try {
                this[_0x28c0("0x61")]() < _0x5004b0 &&
                  this[_0x28c0("0x61")](_0x5004b0);
              } catch (_0x55e917) {}
              this[_0x28c0("0xdd")](_0x28c0("0x9d"));
            }),
          this[_0x28c0("0xef")]({
            src: _0x439681,
            type: _0x28c0("0xfc"),
          }),
          !0x0 !== _0x41459d && this[_0x28c0("0xf1")](),
          this[_0x28c0("0xdd")](_0x28c0("0x9d"));
      },
      setTrack: function (_0x1804dd) {
        var _0x458944,
          _0x15ec38 = this[_0x28c0("0xfd")]();
        for (
          _0x458944 = 0x0;
          _0x458944 < _0x15ec38["\x6c\x65\x6e\x67\x74\x68"];
          _0x458944++
        )
          _0x15ec38[_0x28c0("0xfe")](_0x15ec38[_0x458944]);
        var _0x30bc8d = _0x54c48f[this[_0x28c0("0x80")]][_0x1804dd],
          _0x4cd58e = this[_0x28c0("0xff")](
            "\x73\x75\x62\x74\x69\x74\x6c\x65\x73",
            _0x1804dd,
            _0x1804dd
          );
        for (
          _0x458944 = 0x0;
          _0x458944 < _0x30bc8d[_0x28c0("0x73")];
          _0x458944++
        )
          _0x4cd58e[_0x28c0("0x100")]({
            startTime: _0x30bc8d[_0x458944][_0x28c0("0x63")],
            endTime: _0x30bc8d[_0x458944][_0x28c0("0x64")],
            text: _0x458944,
          });
        _0x4cd58e[_0x28c0("0x101")] = _0x28c0("0x102");
      },
      getMetas: function () {
        return this[_0x28c0("0x7c")];
      },
      setMetas: function (_0x3666e8) {
        (this["\x6d\x65\x74\x61"] = _0x3666e8),
          this[_0x28c0("0x9e")](_0x28c0("0x103"));
      },
      getHistoryUrls: function () {
        return this[_0x28c0("0x1a")][_0x28c0("0x104")];
      },
      getAccessToken: function () {
        return this[_0x28c0("0x76")];
      },
      getNextVideoUrl: function () {
        return this[_0x28c0("0x90")];
      },
      getPreviousVideoUrl: function () {
        return this[_0x28c0("0x91")];
      },
      getAdsEnabled: function () {
        return this["\x61\x64\x73\x45\x6e\x61\x62\x6c\x65\x64"];
      },
      onADNError: function (_0x48ae95) {
        this["\x72\x65\x6d\x6f\x76\x65\x43\x6c\x61\x73\x73"](_0x28c0("0x9d")),
          this[_0x28c0("0xf0")](),
          this["\x65\x72\x72\x6f\x72"](this[_0x28c0("0x96")]["\x6d\x73\x67"]);
      },
      getADNError: function () {
        return this[_0x28c0("0x96")];
      },
      onMetadataLoaded: function (_0xc71e91) {
        this[_0x28c0("0xfd")]() ||
          this["\x73\x65\x74\x54\x72\x61\x63\x6b"](this[_0x28c0("0xde")]),
          this[_0x28c0("0xdd")](_0x28c0("0x9d"));
      },
      onFullscreenChanged: function (_0x1833ef) {
        this[_0x28c0("0x8b")] ||
          this[_0x28c0("0xc3")]() ||
          this["\x76\x69\x64\x65\x6f"][_0x28c0("0xc4")] ==
            window[_0x28c0("0x8d")][_0x28c0("0x8c")] ||
          (window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"] =
            this["\x76\x69\x64\x65\x6f"][_0x28c0("0xc4")] +
            _0x28c0("0x105") +
            Math["\x72\x6f\x75\x6e\x64"](this[_0x28c0("0x61")]()));
      },
      onChromecastCustomData: function () {
        return {
          key: _0x5b3210,
          website_token: _0x340fef,
          access_token: this[_0x28c0("0x76")],
          video_id: this["\x76\x69\x64\x65\x6f"]["\x69\x64"],
          meta: this[_0x28c0("0x106")](),
          currentTime: this[_0x28c0("0x61")](),
          quality: this[_0x28c0("0xe0")],
          language: this[_0x28c0("0xde")],
          withSubtitles: this[_0x28c0("0x82")],
        };
      },
      getHashOptions: function () {
        for (
          var _0x3dd0bf = window[_0x28c0("0x8d")][_0x28c0("0x109")]
              ["\x73\x75\x62\x73\x74\x72"](0x1)
              ["\x73\x70\x6c\x69\x74"]("\x26"),
            _0x1fe64e = {},
            _0x5df1ac = 0x0;
          _0x5df1ac < _0x3dd0bf[_0x28c0("0x73")];
          _0x5df1ac++
        ) {
          var _0x25d553 = _0x3dd0bf[_0x5df1ac][_0x28c0("0x107")]("\x3d");
          if (0x2 == _0x25d553[_0x28c0("0x73")])
            switch (_0x25d553[0x0]) {
              case _0x28c0("0x47"):
                _0x1fe64e[_0x28c0("0x47")] = _0x25d553[0x1];
                break;
              case "\x70\x6f\x73\x69\x74\x69\x6f\x6e":
                _0x1fe64e["\x70\x6f\x73\x69\x74\x69\x6f\x6e"] = _0x25d553[0x1];
            }
        }
        return _0x1fe64e;
      },
      _generateADNT: function (_0x46b194) {
        var _0x10c83e = JSON[_0x28c0("0xb6")](_0x46b194),
          _0x2bf1f5 = new JSEncrypt();
        return (
          _0x2bf1f5[_0x28c0("0x10a")](_0x28c0("0x10b")),
          _0x2bf1f5[_0x28c0("0x10c")](_0x10c83e)
        );
      },
      beforeInitializeHlsjs: function (_0x40330e, _0x2586ad) {
        this[_0x28c0("0x8a")] = !0x0;
        var _0x1289d5 = this;
        _0x2586ad["\x6f\x6e"](
          "\x68\x6c\x73\x4d\x61\x6e\x69\x66\x65\x73\x74\x50\x61\x72\x73\x65\x64",
          function (_0x52004d) {
            0x0 <= _0x2586ad[_0x28c0("0x10d")] &&
              ((_0x1289d5[_0x28c0("0x7d")] =
                _0x2586ad[_0x28c0("0x10e")][
                  _0x2586ad["\x66\x69\x72\x73\x74\x4c\x65\x76\x65\x6c"]
                ]["\x68\x65\x69\x67\x68\x74"]),
              _0x1289d5[_0x28c0("0x9e")](_0x28c0("0xf7")));
          }
        ),
          _0x2586ad["\x6f\x6e"](_0x28c0("0x10f"), function (_0x560b33) {
            0x0 <= _0x2586ad[_0x28c0("0x110")] &&
              ((_0x1289d5[_0x28c0("0x7d")] =
                _0x2586ad["\x6c\x65\x76\x65\x6c\x73"][
                  _0x2586ad[_0x28c0("0x110")]
                ][_0x28c0("0x2d")]),
              _0x1289d5[_0x28c0("0x9e")](
                "\x61\x64\x6e\x2e\x73\x6f\x75\x72\x63\x65\x53\x77\x69\x74\x63\x68"
              ));
          });
      },
      onTimeUpdated: function () {
        this[_0x28c0("0x8a")] ||
          (0x0 !== this[_0x28c0("0x111")]() &&
            this[_0x28c0("0x7d")] != this[_0x28c0("0x111")]() &&
            ((this[_0x28c0("0x7d")] = this[_0x28c0("0x111")]()),
            that["\x74\x72\x69\x67\x67\x65\x72"](_0x28c0("0xf7"))));
      },
    });
  (_0x329109[_0x28c0("0x112")] = _0x20388e[_0x28c0("0x112")]),
    videojs[_0x28c0("0x113")](_0x28c0("0x54"), _0x329109);
  var _0x3e3490 = videojs[_0x28c0("0x53")](_0x28c0("0x114")),
    _0x5753eb = videojs[_0x28c0("0x75")](_0x3e3490, {
      constructor: function (_0x304611, _0x29fda1, _0x245648) {
        _0x3e3490["\x61\x70\x70\x6c\x79"](this, arguments),
          _0x304611["\x6f\x6e"](
            _0x28c0("0x115"),
            videojs["\x62\x69\x6e\x64"](
              this,
              this["\x6f\x6e\x53\x65\x65\x6b\x69\x6e\x67"]
            )
          ),
          _0x304611["\x6f\x6e"](
            _0x28c0("0x117"),
            videojs["\x62\x69\x6e\x64"](
              this,
              this["\x6f\x6e\x53\x65\x65\x6b\x65\x64"]
            )
          ),
          window[
            "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
          ](
            _0x28c0("0x118"),
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x119")])
          ),
          (this[_0x28c0("0x11a")] = !0x1),
          (this[_0x28c0("0x11b")] = !0x1),
          _0x304611["\x6f\x6e"](
            _0x28c0("0x11c"),
            videojs[_0x28c0("0x5d")](
              this,
              this["\x68\x69\x64\x65\x53\x75\x62\x74\x69\x74\x6c\x65\x73"]
            )
          ),
          _0x304611["\x6f\x6e"](
            _0x28c0("0x11e"),
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x11f")])
          );
      },
    });
  (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x120")] = function (_0x3b869e) {
    return _0x3b869e["\x72\x65\x70\x6c\x61\x63\x65"](/<[^>]*>/g, "");
  }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x122")] = function (_0x472bec) {
      var _0xc35453 =
        _0x472bec[_0x28c0("0x9")](_0x28c0("0x123")) <
          _0x472bec[_0x28c0("0x9")]("\x0a") &&
        0x0 <= _0x472bec[_0x28c0("0x9")]("\x3c\x69\x3e");
      if (!_0xc35453) return _0x472bec;
      for (
        var _0x3991df = _0x472bec[_0x28c0("0x107")]("\x0a"), _0xaf95b1 = 0x0;
        _0xaf95b1 < _0x3991df[_0x28c0("0x73")];
        _0xaf95b1++
      ) {
        var _0x3bbbe6 = _0x3991df[_0xaf95b1][_0x28c0("0x9")](_0x28c0("0x123")),
          _0x376030 = _0x3991df[_0xaf95b1][_0x28c0("0x9")](_0x28c0("0x124"));
        _0xc35453 &&
          -0x1 == _0x3bbbe6 &&
          (_0x3991df[_0xaf95b1] = "\x3c\x69\x3e" + _0x3991df[_0xaf95b1]),
          (_0xc35453 || 0x0 <= _0x3bbbe6) &&
            -0x1 == _0x376030 &&
            (_0x3991df[_0xaf95b1] = _0x3991df[_0xaf95b1] + _0x28c0("0x124"));
      }
      return _0x3991df[_0x28c0("0x74")]("\x0a");
    }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x125")] = function (_0x413d48) {
      for (var _0x55d946 = []; 0x0 < _0x413d48["\x6c\x65\x6e\x67\x74\x68"]; ) {
        var _0x2b16f3 = _0x413d48[_0x28c0("0x9")]("\x3c\x69\x3e");
        if (-0x1 == _0x2b16f3) {
          _0x55d946[_0x28c0("0x6f")](""),
            _0x55d946[_0x28c0("0x6f")](this[_0x28c0("0x120")](_0x413d48));
          break;
        }
        0x0 < _0x2b16f3 &&
          (_0x55d946[_0x28c0("0x6f")](""),
          _0x55d946[_0x28c0("0x6f")](
            this[_0x28c0("0x120")](_0x413d48[_0x28c0("0x108")](0x0, _0x2b16f3))
          ),
          (_0x413d48 = _0x413d48["\x73\x75\x62\x73\x74\x72"](_0x2b16f3)),
          (_0x2b16f3 = 0x0)),
          (_0x2b16f3 = _0x413d48[_0x28c0("0x9")]("\x3c\x2f\x69\x3e")),
          _0x55d946[_0x28c0("0x6f")]("\x69\x74\x61\x6c\x69\x63"),
          _0x55d946[_0x28c0("0x6f")](
            this[_0x28c0("0x120")](
              _0x413d48[_0x28c0("0x108")](0x3, _0x2b16f3 - 0x3)
            )
          ),
          (_0x413d48 = _0x413d48[_0x28c0("0x108")](_0x2b16f3 + 0x4));
      }
      return _0x55d946;
    }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x11f")] = function () {
      (this[_0x28c0("0x11b")] = !0x1), this[_0x28c0("0x126")]();
    }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x11d")] = function () {
      this["\x6e\x6f\x53\x75\x62\x74\x69\x74\x6c\x65\x73"] = !0x0;
    }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x116")] = function () {
      (this[_0x28c0("0x115")] = !0x0), this[_0x28c0("0x126")]();
    }),
    (_0x5753eb[_0x28c0("0xe4")][
      "\x6f\x6e\x53\x65\x65\x6b\x65\x64"
    ] = function () {
      (this["\x73\x65\x65\x6b\x69\x6e\x67"] = !0x1),
        (this["\x66\x6f\x72\x63\x65\x52\x65\x64\x72\x61\x77"] = !0x0),
        this["\x75\x70\x64\x61\x74\x65\x44\x69\x73\x70\x6c\x61\x79"]();
    }),
    (_0x5753eb["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      "\x6f\x6e\x52\x65\x73\x69\x7a\x65"
    ] = function () {
      (this[_0x28c0("0x11a")] = !0x0), this[_0x28c0("0x128")]();
    }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x129")] = function () {
      var _0x5c403f = document[_0x28c0("0xc")](_0x28c0("0x12a"));
      return (_0x5c403f[_0x28c0("0xd")] = _0x28c0("0x12b")), _0x5c403f;
    }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x12c")] = function (_0x33245c) {
      if (this[_0x28c0("0x11b")]) return !0x1;
      if (this[_0x28c0("0x115")]) return !0x1;
      if (this[_0x28c0("0x11a")]) return !0x0;
      if (this[_0x28c0("0x12d")]) return !0x0;
      if (
        this[_0x28c0("0x12e")]["\x6c\x65\x6e\x67\x74\x68"] !=
        _0x33245c[_0x28c0("0x73")]
      )
        return !0x0;
      for (
        var _0x2a4db0 = _0x33245c[_0x28c0("0x73")] - 0x1;
        0x0 <= _0x2a4db0;
        _0x2a4db0--
      )
        if (
          _0x33245c[_0x2a4db0][_0x28c0("0x12f")] !=
          this[_0x28c0("0x12e")][_0x2a4db0]["\x74\x65\x78\x74"]
        )
          return !0x0;
      return !0x1;
    }),
    (_0x5753eb["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      _0x28c0("0x130")
    ] = function (_0x28133b) {
      var _0x4d53c2 =
          _0x54c48f[
            this[_0x28c0("0x131")]["\x74\x72\x61\x63\x6b\x49\x6e\x64\x65\x78"]
          ][this[_0x28c0("0x131")][_0x28c0("0xde")]],
        _0x441bbc = _0x28133b[_0x28c0("0x12e")];
      if (_0x441bbc) {
        var _0x3965a3,
          _0x57f94f = this[_0x28c0("0x132")],
          _0xbea2ad = _0x57f94f[_0x28c0("0x133")]("\x32\x64"),
          _0x250a73 = [];
        for (
          _0x3965a3 = 0x0;
          _0x3965a3 < _0x441bbc["\x6c\x65\x6e\x67\x74\x68"];
          _0x3965a3++
        )
          _0x250a73[_0x28c0("0x6f")](_0x441bbc[_0x3965a3]);
        if (
          ((this[_0x28c0("0x12e")] = this[_0x28c0("0x12e")] || []),
          this[_0x28c0("0x12c")](_0x250a73))
        ) {
          (this[_0x28c0("0x12d")] = !0x1),
            (this[_0x28c0("0x11a")] = !0x1),
            (this[_0x28c0("0x12e")] = _0x250a73);
          var _0x3c7897 = this[_0x28c0("0x131")][_0x28c0("0x111")](),
            _0x53b56e = this[_0x28c0("0x131")][
              "\x76\x69\x64\x65\x6f\x57\x69\x64\x74\x68"
            ]();
          if (0x0 != _0x3c7897 && 0x0 != _0x53b56e) {
            var _0x374d00 = this[_0x28c0("0x131")]["\x65\x6c\x5f"][
                _0x28c0("0x135")
              ],
              _0x32ec70 = this["\x70\x6c\x61\x79\x65\x72\x5f"][
                _0x28c0("0x132")
              ][_0x28c0("0x136")],
              _0x2b7502 = _0x53b56e / _0x3c7897 / (_0x32ec70 / _0x374d00);
            0x1 < _0x2b7502
              ? ((_0x57f94f[_0x28c0("0x2b")] = _0x32ec70),
                (_0x57f94f[_0x28c0("0x2d")] =
                  ((_0x32ec70 * _0x3c7897) / _0x53b56e) | 0x0))
              : _0x2b7502 < 0x1
              ? ((_0x57f94f[_0x28c0("0x2d")] = _0x374d00),
                (_0x57f94f[_0x28c0("0x2b")] =
                  ((_0x374d00 * _0x53b56e) / _0x3c7897) | 0x0))
              : ((_0x57f94f["\x77\x69\x64\x74\x68"] = _0x32ec70),
                (_0x57f94f[_0x28c0("0x2d")] = _0x374d00)),
              (_0x57f94f[_0x28c0("0x18")][_0x28c0("0x137")] =
                (_0x32ec70 - _0x57f94f[_0x28c0("0x2b")]) / 0x2 + "\x70\x78"),
              (_0x57f94f[_0x28c0("0x18")][_0x28c0("0x138")] =
                (_0x374d00 - _0x57f94f[_0x28c0("0x2d")]) / 0x2 + "\x70\x78");
            var _0x64e284 = ((0x3c * _0x57f94f[_0x28c0("0x2d")]) / 0x438) | 0x0,
              _0x2db5d7 = 1.1 * _0x64e284;
            _0xbea2ad[_0x28c0("0x139")](
              0x0,
              0x0,
              _0x57f94f[_0x28c0("0x2b")],
              _0x57f94f[_0x28c0("0x2d")]
            ),
              (_0xbea2ad["\x66\x6f\x6e\x74"] =
                "\x62\x6f\x6c\x64\x20" + _0x64e284 + _0x28c0("0x13b")),
              (_0xbea2ad["\x6c\x69\x6e\x65\x57\x69\x64\x74\x68"] = Math[
                _0x28c0("0x13d")
              ]((0x8 * _0x57f94f[_0x28c0("0x2d")]) / 0x438, 0x4)),
              (_0xbea2ad[_0x28c0("0x13e")] = _0x28c0("0x13f")),
              (_0xbea2ad[_0x28c0("0x140")] = 0x2);
            var _0x5d554a = {
              start: {
                start: [],
                middle: [],
                end: [],
              },
              middle: {
                start: [],
                middle: [],
                end: [],
              },
              end: {
                start: [],
                middle: [],
                end: [],
              },
            };
            _0x3965a3 = _0x250a73[_0x28c0("0x73")];
            for (var _0x4c7fdf = null; _0x3965a3--; ) {
              var _0xaf44f7 = _0x250a73[_0x3965a3];
              _0xaf44f7 &&
                _0x5d554a[
                  (_0x4c7fdf = _0x4d53c2[_0xaf44f7[_0x28c0("0x12f")]])[
                    "\x6c\x69\x6e\x65\x41\x6c\x69\x67\x6e"
                  ]
                ][
                  _0x4c7fdf[
                    "\x70\x6f\x73\x69\x74\x69\x6f\x6e\x41\x6c\x69\x67\x6e"
                  ]
                ][_0x28c0("0x6f")](_0x4c7fdf[_0x28c0("0x12f")]);
            }
            for (var _0x2bce91 in _0x5d554a)
              if (_0x5d554a[_0x28c0("0xd3")](_0x2bce91))
                for (var _0x40760e in _0x5d554a[_0x2bce91])
                  if (
                    _0x5d554a[_0x2bce91][
                      "\x68\x61\x73\x4f\x77\x6e\x50\x72\x6f\x70\x65\x72\x74\x79"
                    ](_0x40760e)
                  ) {
                    var _0xaf6ea2 = this[_0x28c0("0x122")](
                      _0x5d554a[_0x2bce91][_0x40760e]["\x6a\x6f\x69\x6e"](
                        "\x0a"
                      )
                    );
                    _0xaf6ea2 = _0xaf6ea2[_0x28c0("0x107")]("\x0a");
                    for (
                      var _0x2acfe7 = 0x0;
                      _0x2acfe7 < _0xaf6ea2[_0x28c0("0x73")];
                      _0x2acfe7++
                    ) {
                      _0x4c7fdf = this[_0x28c0("0x125")](_0xaf6ea2[_0x2acfe7]);
                      var _0x324b6b = 0x0,
                        _0x362a1e = [],
                        _0x8277ff = 0x0;
                      for (
                        _0x324b6b = 0x0;
                        _0x324b6b < _0x4c7fdf[_0x28c0("0x73")];
                        _0x324b6b += 0x2
                      ) {
                        _0xbea2ad[_0x28c0("0x13a")] =
                          _0x4c7fdf[_0x324b6b] +
                          _0x28c0("0x143") +
                          _0x64e284 +
                          _0x28c0("0x13b");
                        var _0x1dda65 = _0xbea2ad[_0x28c0("0x144")](
                          _0x4c7fdf[_0x324b6b + 0x1]
                        )[_0x28c0("0x2b")];
                        _0x362a1e[_0x28c0("0x6f")](_0x1dda65),
                          (_0x8277ff += _0x1dda65);
                      }
                      var _0x321991 = 0x0;
                      for (
                        _0x324b6b = 0x0;
                        _0x324b6b < _0x4c7fdf[_0x28c0("0x73")];
                        _0x324b6b += 0x2
                      ) {
                        var _0x44bfa4 = 0x0,
                          _0x61386e = 0x0;
                        _0x28c0("0x145") == _0x2bce91
                          ? ((_0xbea2ad[_0x28c0("0x146")] = "\x74\x6f\x70"),
                            (_0x44bfa4 =
                              0.1 * _0x57f94f[_0x28c0("0x2d")] +
                              _0x2acfe7 * _0x2db5d7))
                          : "\x73\x74\x61\x72\x74" == _0x2bce91
                          ? ((_0xbea2ad[_0x28c0("0x146")] =
                              "\x62\x6f\x74\x74\x6f\x6d"),
                            (_0x44bfa4 =
                              0.9 * _0x57f94f["\x68\x65\x69\x67\x68\x74"] -
                              (_0xaf6ea2[_0x28c0("0x73")] - _0x2acfe7 - 0x1) *
                                _0x2db5d7))
                          : ((_0xbea2ad[_0x28c0("0x146")] = _0x28c0("0x147")),
                            (_0x44bfa4 =
                              _0x57f94f[_0x28c0("0x2d")] / 0x2 -
                              (_0xaf6ea2["\x6c\x65\x6e\x67\x74\x68"] / 0x2) *
                                _0x2db5d7 +
                              _0x2acfe7 * _0x2db5d7)),
                          (_0x61386e =
                            "\x65\x6e\x64" == _0x40760e
                              ? 0.9 * _0x57f94f[_0x28c0("0x2b")] -
                                _0x8277ff +
                                _0x321991
                              : _0x28c0("0x148") == _0x40760e
                              ? 0.1 * _0x57f94f[_0x28c0("0x2b")] + _0x321991
                              : 0.5 * (_0x57f94f[_0x28c0("0x2b")] - _0x8277ff) +
                                _0x321991),
                          (_0x44bfa4 |= 0x0),
                          (_0x61386e |= 0x0),
                          (_0xbea2ad[_0x28c0("0x13a")] =
                            _0x4c7fdf[_0x324b6b] +
                            _0x28c0("0x143") +
                            _0x64e284 +
                            _0x28c0("0x13b")),
                          (_0xbea2ad[_0x28c0("0x149")] = _0x28c0("0x14a")),
                          _0xbea2ad[_0x28c0("0x14b")](
                            _0x4c7fdf[_0x324b6b + 0x1],
                            _0x61386e,
                            _0x44bfa4
                          ),
                          (_0xbea2ad["\x66\x69\x6c\x6c\x53\x74\x79\x6c\x65"] =
                            "\x23\x46\x46\x46"),
                          _0xbea2ad[_0x28c0("0x14c")](
                            _0x4c7fdf[_0x324b6b + 0x1],
                            _0x61386e,
                            _0x44bfa4
                          ),
                          (_0x321991 += _0x362a1e[_0x324b6b / 0x2]);
                      }
                    }
                  }
          }
        }
      }
    }),
    (_0x5753eb[_0x28c0("0xe4")][_0x28c0("0x126")] = function () {
      var _0x5b7525 = this[_0x28c0("0x132")];
      _0x5b7525[_0x28c0("0x133")]("\x32\x64")[_0x28c0("0x139")](
        0x0,
        0x0,
        _0x5b7525[_0x28c0("0x2b")],
        _0x5b7525[_0x28c0("0x2d")]
      ),
        (this[_0x28c0("0x12d")] = !0x0);
    }),
    videojs[_0x28c0("0x113")](_0x28c0("0x114"), _0x5753eb);
})(),
  (function () {
    var _0x3f8818 = (function () {
      var _0x54bcca = !![];
      return function (_0x3515fd, _0x13d7b0) {
        var _0x41df6c = _0x54bcca
          ? function () {
              if (_0x13d7b0) {
                var _0x721bd7 = _0x13d7b0["\x61\x70\x70\x6c\x79"](
                  _0x3515fd,
                  arguments
                );
                _0x13d7b0 = null;
                return _0x721bd7;
              }
            }
          : function () {};
        _0x54bcca = ![];
        return _0x41df6c;
      };
    })();
    var _0xe655c4 = function () {
      var _0x1e1166 = _0x3f8818(this, function () {
        var _0x3942cb = function () {
            return "\x64\x65\x76";
          },
          _0x522c86 = function () {
            return "\x77\x69\x6e\x64\x6f\x77";
          };
        var _0x2d811f = function () {
          var _0x5be15a = new RegExp(
            "\x5c\x77\x2b\x20\x2a\x5c\x28\x5c\x29\x20\x2a\x7b\x5c\x77\x2b\x20\x2a\x5b\x27\x7c\x22\x5d\x2e\x2b\x5b\x27\x7c\x22\x5d\x3b\x3f\x20\x2a\x7d"
          );
          return !_0x5be15a["\x74\x65\x73\x74"](
            _0x3942cb["\x74\x6f\x53\x74\x72\x69\x6e\x67"]()
          );
        };
        var _0xaba6b1 = function () {
          var _0x564f69 = new RegExp(
            "\x28\x5c\x5c\x5b\x78\x7c\x75\x5d\x28\x5c\x77\x29\x7b\x32\x2c\x34\x7d\x29\x2b"
          );
          return _0x564f69["\x74\x65\x73\x74"](
            _0x522c86["\x74\x6f\x53\x74\x72\x69\x6e\x67"]()
          );
        };
        var _0x363723 = function (_0x3baec9) {
          var _0x23d816 = ~-0x1 >> (0x1 + (0xff % 0x0));
          if (_0x3baec9["\x69\x6e\x64\x65\x78\x4f\x66"]("\x69" === _0x23d816)) {
            _0x4bff25(_0x3baec9);
          }
        };
        var _0x4bff25 = function (_0x495262) {
          var _0x479fec = ~-0x4 >> (0x1 + (0xff % 0x0));
          if (
            _0x495262["\x69\x6e\x64\x65\x78\x4f\x66"]((!![] + "")[0x3]) !==
            _0x479fec
          ) {
            _0x363723(_0x495262);
          }
        };
        if (!_0x2d811f()) {
          if (!_0xaba6b1()) {
            _0x363723("\x69\x6e\x64\u0435\x78\x4f\x66");
          } else {
            _0x363723("\x69\x6e\x64\x65\x78\x4f\x66");
          }
        } else {
          _0x363723("\x69\x6e\x64\u0435\x78\x4f\x66");
        }
      });
      _0x1e1166();
      var _0x29851f,
        _0x25b601 = [
          (_0x29851f = 0x9e5e),
          (_0x29851f += 0x15222),
          (_0x29851f += -0x16df0),
          (_0x29851f += -0x8017),
        ];
      (_0x25b601[0x3] = (0x1bb36 * _0x25b601[0x3]) % (0x2 << 0x10)),
        (_0x25b601[0x1] = _0x25b601[0x0] * _0x25b601[0x1]);
      for (var _0x5a1373 = 0x0; _0x5a1373 < 0xf; _0x5a1373++)
        _0x25b601[0x2] += _0x5a1373;
      for (_0x5a1373 = 0x9; _0x5a1373 < 0xb; _0x5a1373++)
        _0x25b601[0x0] += _0x5a1373;
      (_0x25b601[0x2] = _0x25b601[0x1] ^ _0x25b601[0x2]),
        _0x3c562c(
          _0x25b601[_0x28c0("0x14d")](function (_0x39607c) {
            return (_0x28c0("0x14e") + _0x39607c[_0x28c0("0xdb")](0x10))[
              _0x28c0("0x108")
            ](-0x4);
          })[_0x28c0("0x74")]("")
        );
    };
    _0xe655c4(), (_0xe655c4 = {});
  })(),
  (function () {
    var _0x31627f = videojs[_0x28c0("0x53")](
        "\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74"
      ),
      _0x5be4ea = videojs[_0x28c0("0x75")](_0x31627f, {
        constructor: function () {
          _0x31627f[_0x28c0("0x93")](this, arguments),
            (this[_0x28c0("0x14f")] = !0x1),
            this[_0x28c0("0x150")](),
            this["\x65\x6c"]()[_0x28c0("0xac")](
              "\x63\x6c\x69\x63\x6b",
              videojs["\x62\x69\x6e\x64"](this, this[_0x28c0("0x151")])
            ),
            this["\x70\x6c\x61\x79\x65\x72\x5f"]
              ["\x65\x6c"]()
              [_0x28c0("0xac")](
                "\x63\x6c\x69\x63\x6b",
                videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x152")])
              );
        },
      });
    (_0x5be4ea["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      _0x28c0("0x151")
    ] = function () {
      this[_0x28c0("0x131")][_0x28c0("0x153")]()
        ? this["\x70\x6c\x61\x79\x65\x72\x5f"][_0x28c0("0xf1")]()
        : this[_0x28c0("0x131")]["\x70\x61\x75\x73\x65"](),
        this[_0x28c0("0x152")]();
    }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x129")] = function () {
        var _0x46edff = document[
          "\x63\x72\x65\x61\x74\x65\x45\x6c\x65\x6d\x65\x6e\x74"
        ](_0x28c0("0x20"));
        return (
          (_0x46edff[_0x28c0("0xd")] = _0x28c0("0x154")),
          (_0x46edff[_0x28c0("0x18")][_0x28c0("0xcc")] = _0x28c0("0x155")),
          (_0x46edff[_0x28c0("0x18")][_0x28c0("0x156")] = "\x30"),
          (_0x46edff[_0x28c0("0x18")][_0x28c0("0x157")] = "\x30"),
          (_0x46edff[_0x28c0("0x18")]["\x6c\x65\x66\x74"] = "\x30"),
          (_0x46edff[_0x28c0("0x18")][_0x28c0("0x159")] = "\x30"),
          (this[_0x28c0("0x15a")] = document[_0x28c0("0xc")](_0x28c0("0x20"))),
          (this["\x70\x6f\x70\x75\x70"][_0x28c0("0xd")] = _0x28c0("0x15b")),
          (this[_0x28c0("0x15a")][_0x28c0("0xf")] = _0x28c0("0x15c")),
          _0x46edff
        );
      }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x15d")] = function (_0x475d90) {
        var _0x3d9643 = this[_0x28c0("0x15e")](_0x475d90);
        this[_0x28c0("0x14f")] &&
          this["\x68\x69\x64\x65\x50\x6f\x70\x75\x70"](),
          (this["\x70\x6f\x70\x75\x70"][_0x28c0("0x18")][_0x28c0("0x158")] =
            _0x3d9643["\x78"] + "\x70\x78"),
          (this[_0x28c0("0x15a")][_0x28c0("0x18")]["\x74\x6f\x70"] =
            _0x3d9643["\x79"] + "\x70\x78"),
          this["\x65\x6c"]()[_0x28c0("0x11")](this["\x70\x6f\x70\x75\x70"]),
          (this[_0x28c0("0x14f")] = !0x0);
      }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x152")] = function () {
        this[_0x28c0("0x14f")] &&
          (this["\x65\x6c"]()[_0x28c0("0x15f")](this[_0x28c0("0x15a")]),
          (this[_0x28c0("0x14f")] = !0x1));
      }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x150")] = function () {
        document[
          "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
        ](
          _0x28c0("0x160"),
          videojs[_0x28c0("0x5d")](
            this,
            function (_0x114e2a) {
              if (
                _0x28c0("0x154") ===
                  _0x114e2a[_0x28c0("0x161")][_0x28c0("0xd")] ||
                _0x28c0("0x162") === _0x114e2a[_0x28c0("0x161")][_0x28c0("0xd")]
              )
                return (
                  this[_0x28c0("0x15d")](_0x114e2a),
                  void _0x114e2a[
                    "\x70\x72\x65\x76\x65\x6e\x74\x44\x65\x66\x61\x75\x6c\x74"
                  ]()
                );
              null != _0x114e2a[_0x28c0("0x163")] &&
                -0x1 <
                  _0x114e2a[_0x28c0("0x163")][
                    "\x63\x6c\x61\x73\x73\x4e\x61\x6d\x65"
                  ][_0x28c0("0x9")](_0x28c0("0x2a")) &&
                _0x114e2a[_0x28c0("0x164")]();
            },
            !0x1
          )
        );
      }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x165")] = function (_0x2effe6) {
        var _0x5eba8b;
        return (
          _0x2effe6 || (_0x2effe6 = window[_0x28c0("0x166")]),
          _0x2effe6[_0x28c0("0x161")]
            ? (_0x5eba8b = _0x2effe6[_0x28c0("0x161")])
            : _0x2effe6["\x73\x72\x63\x45\x6c\x65\x6d\x65\x6e\x74"] &&
              (_0x5eba8b = _0x2effe6[_0x28c0("0x167")]),
          0x3 == _0x5eba8b[_0x28c0("0x168")] &&
            (_0x5eba8b = _0x5eba8b[_0x28c0("0x169")]),
          _0x5eba8b
        );
      }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x16a")] = function (_0x2919ed) {
        var _0x560a19 = 0x0,
          _0x35a70d = 0x0;
        return (
          _0x2919ed || (_0x2919ed = window[_0x28c0("0x166")]),
          _0x2919ed[_0x28c0("0x16b")] || _0x2919ed["\x70\x61\x67\x65\x59"]
            ? ((_0x560a19 = _0x2919ed[_0x28c0("0x16b")]),
              (_0x35a70d = _0x2919ed["\x70\x61\x67\x65\x59"]))
            : (_0x2919ed[_0x28c0("0x16d")] ||
                _0x2919ed["\x63\x6c\x69\x65\x6e\x74\x59"]) &&
              ((_0x560a19 =
                _0x2919ed[_0x28c0("0x16d")] +
                document[_0x28c0("0x16e")][_0x28c0("0x16f")] +
                document[_0x28c0("0x170")][_0x28c0("0x16f")]),
              (_0x35a70d =
                _0x2919ed[_0x28c0("0x171")] +
                document[_0x28c0("0x16e")][
                  "\x73\x63\x72\x6f\x6c\x6c\x54\x6f\x70"
                ] +
                document[_0x28c0("0x170")][_0x28c0("0x172")])),
          {
            x: _0x560a19,
            y: _0x35a70d,
          }
        );
      }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x173")] = function (_0x4bd3c8) {
        return {
          left:
            (_0x4bd3c8 = _0x4bd3c8[_0x28c0("0x174")]())[_0x28c0("0x158")] +
            window[_0x28c0("0x175")],
          top:
            _0x4bd3c8[_0x28c0("0x156")] +
            window["\x73\x63\x72\x6f\x6c\x6c\x59"],
        };
      }),
      (_0x5be4ea[_0x28c0("0xe4")][_0x28c0("0x15e")] = function (_0x5d1ba2) {
        var _0x14716c = this[_0x28c0("0x16a")](_0x5d1ba2),
          _0x511828 = this[_0x28c0("0x165")](_0x5d1ba2),
          _0x10f12c = this["\x66\x69\x6e\x64\x50\x6f\x73"](_0x511828);
        return {
          x: _0x14716c["\x78"] - _0x10f12c[_0x28c0("0x158")],
          y: _0x14716c["\x79"] - _0x10f12c[_0x28c0("0x156")],
        };
      }),
      videojs[
        "\x72\x65\x67\x69\x73\x74\x65\x72\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74"
      ]("\x43\x6c\x69\x63\x6b\x74\x68\x72\x6f\x75\x67\x68", _0x5be4ea);
  })(),
  (function () {
    var _0x580fa8 = videojs[_0x28c0("0x53")](_0x28c0("0x177")),
      _0x4b54f0 = videojs["\x65\x78\x74\x65\x6e\x64"](_0x580fa8, {
        constructor: function (_0x40fee6) {
          _0x580fa8[_0x28c0("0x93")](this, arguments),
            _0x40fee6["\x6f\x6e"](
              _0x28c0("0x103"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x178")])
            ),
            this["\x75\x70\x64\x61\x74\x65\x4d\x65\x74\x61"](),
            this[_0x28c0("0x179")](),
            _0x40fee6["\x6f\x6e"](
              "\x76\x61\x73\x74\x2e\x61\x64\x53\x74\x61\x72\x74",
              videojs["\x62\x69\x6e\x64"](this, this["\x68\x69\x64\x65"])
            ),
            _0x40fee6["\x6f\x6e"](
              _0x28c0("0x17a"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
            ),
            _0x40fee6["\x6f\x6e"](
              _0x28c0("0x17c"),
              videojs["\x62\x69\x6e\x64"](this, this[_0x28c0("0x17b")])
            );
        },
      });
    (_0x4b54f0["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      _0x28c0("0x178")
    ] = function () {
      var _0x2bc56e = this["\x70\x6c\x61\x79\x65\x72\x5f"][_0x28c0("0x106")]();
      _0x2bc56e[_0x28c0("0x17d")] &&
        (this[_0x28c0("0x17e")][_0x28c0("0xf")] = _0x2bc56e[_0x28c0("0x17d")]),
        _0x2bc56e[_0x28c0("0x17f")] &&
          (this[_0x28c0("0x180")]["\x69\x6e\x6e\x65\x72\x48\x54\x4d\x4c"] =
            _0x2bc56e[_0x28c0("0x17f")]),
        _0x2bc56e[_0x28c0("0x181")] &&
          (this[_0x28c0("0x182")][_0x28c0("0xf")] =
            _0x2bc56e[_0x28c0("0x181")]),
        _0x2bc56e[_0x28c0("0x183")] &&
          (this[_0x28c0("0x184")][_0x28c0("0x18")][_0x28c0("0x2b")] =
            (((_0x2bc56e[_0x28c0("0x183")] / 0x5) * 0x64) | 0x0) + "\x25");
    }),
      (_0x4b54f0["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
        "\x63\x72\x65\x61\x74\x65\x45\x6c"
      ] = function () {
        var _0x49200d = document[_0x28c0("0xc")]("\x64\x69\x76");
        _0x49200d[_0x28c0("0xd")] = _0x28c0("0x185");
        var _0x13b7c5 = document[_0x28c0("0xc")]("\x68\x32");
        (_0x13b7c5["\x63\x6c\x61\x73\x73\x4e\x61\x6d\x65"] = _0x28c0("0x186")),
          _0x49200d[_0x28c0("0x11")](_0x13b7c5),
          (this[_0x28c0("0x17e")] = _0x13b7c5);
        var _0x2ec39b = document[
          "\x63\x72\x65\x61\x74\x65\x45\x6c\x65\x6d\x65\x6e\x74"
        ](_0x28c0("0x20"));
        (_0x2ec39b[_0x28c0("0xd")] =
          "\x76\x6a\x73\x2d\x6d\x65\x74\x61\x2d\x73\x75\x62\x74\x69\x74\x6c\x65"),
          _0x49200d[_0x28c0("0x11")](_0x2ec39b),
          (this[
            "\x73\x75\x62\x74\x69\x74\x6c\x65\x43\x6f\x6e\x74\x61\x69\x6e\x65\x72"
          ] = _0x2ec39b);
        var _0x5d1489 = document[_0x28c0("0xc")](_0x28c0("0x20"));
        (_0x5d1489[_0x28c0("0xd")] = _0x28c0("0x187")),
          _0x49200d[_0x28c0("0x11")](_0x5d1489),
          (this[_0x28c0("0x182")] = _0x5d1489);
        var _0x44d203 = document[_0x28c0("0xc")](_0x28c0("0x20"));
        (_0x44d203[_0x28c0("0xd")] =
          "\x76\x6a\x73\x2d\x6d\x65\x74\x61\x2d\x72\x61\x74\x69\x6e\x67"),
          _0x49200d["\x61\x70\x70\x65\x6e\x64\x43\x68\x69\x6c\x64"](_0x44d203),
          (this[_0x28c0("0x188")] = _0x44d203);
        var _0x13b8fe = document[_0x28c0("0xc")](_0x28c0("0x20"));
        return (
          (_0x13b8fe[_0x28c0("0xd")] = _0x28c0("0x189")),
          _0x44d203[_0x28c0("0x11")](_0x13b8fe),
          (this[_0x28c0("0x184")] = _0x13b8fe),
          _0x49200d
        );
      }),
      videojs[_0x28c0("0x113")](_0x28c0("0x18a"), _0x4b54f0);
  })(),
  (ADNCountDown[_0x28c0("0xe4")][_0x28c0("0x6d")] = function () {
    var _0x6dd7f2 = new Date(),
      _0x22e619 = Math["\x72\x6f\x75\x6e\x64"](
        (this[_0x28c0("0x64")][_0x28c0("0x65")]() -
          _0x6dd7f2[_0x28c0("0x65")]()) /
          0x3e8
      );
    _0x22e619 <= 0x0 && this[_0x28c0("0xd4")]();
    var _0x4dba3f = _0x22e619 % 0x3c,
      _0x2f3728 = (_0x22e619 = (_0x22e619 - _0x4dba3f) / 0x3c) % 0x3c,
      _0x4c2584 = (_0x22e619 = (_0x22e619 - _0x2f3728) / 0x3c) % 0x18,
      _0x1837e4 = (_0x22e619 - _0x4c2584) / 0x18;
    (_0x4dba3f = ("\x30\x30" + _0x4dba3f)[_0x28c0("0x18b")](-0x2)),
      (_0x2f3728 = ("\x30\x30" + _0x2f3728)[_0x28c0("0x18b")](-0x2)),
      (_0x4c2584 = ("\x30\x30" + _0x4c2584)[_0x28c0("0x18b")](-0x2)),
      (this[_0x28c0("0x6a")][_0x28c0("0xf")] = [
        _0x1837e4,
        _0x4c2584,
        _0x2f3728,
        _0x4dba3f,
      ][_0x28c0("0x74")]("\x3a"));
  }),
  (ADNCountDown[_0x28c0("0xe4")][
    "\x70\x61\x72\x73\x65\x54\x69\x6d\x65"
  ] = function (_0x11dadd) {
    var _0x247577 = _0x11dadd[_0x28c0("0x107")]("\x20"),
      _0x1026a6 = _0x247577[0x0][_0x28c0("0x107")]("\x2d"),
      _0x20a6a0 = _0x247577[0x1][_0x28c0("0x107")]("\x3a");
    return new Date(
      _0x1026a6[0x0],
      _0x1026a6[0x1] - 0x1,
      _0x1026a6[0x2],
      _0x20a6a0[0x0],
      _0x20a6a0[0x1],
      _0x20a6a0[0x2]
    );
  }),
  (ADNCountDown[_0x28c0("0xe4")][_0x28c0("0x18c")] = function () {
    this[_0x28c0("0x60")]["\x72\x65\x6d\x6f\x76\x65\x43\x68\x69\x6c\x64"](
      this[_0x28c0("0x66")]
    ),
      clearTimeout(this["\x74\x69\x6d\x65\x72"]);
  }),
  (ADNCountDown[_0x28c0("0xe4")][
    "\x73\x74\x61\x72\x74\x50\x6c\x61\x79\x65\x72"
  ] = function () {
    this["\x64\x65\x69\x6e\x69\x74"](), this[_0x28c0("0x46")]();
  }),
  (function () {
    var _0x406057 = (function () {
      var _0x207220 = !![];
      return function (_0x3c3c07, _0x437577) {
        var _0x49f9f8 = _0x207220
          ? function () {
              if (_0x437577) {
                var _0x9d1ca4 = _0x437577[_0x28c0("0x93")](
                  _0x3c3c07,
                  arguments
                );
                _0x437577 = null;
                return _0x9d1ca4;
              }
            }
          : function () {};
        _0x207220 = ![];
        return _0x49f9f8;
      };
    })();
    var _0x157f11 = _0x406057(this, function () {
      var _0x1947bb = Function(
        _0x28c0("0x18d") + _0x28c0("0x18e") + "\x29\x3b"
      );
      var _0x4b25e5 = function () {};
      var _0x29e556 = _0x1947bb();
      if (!_0x29e556[_0x28c0("0x18f")]) {
        _0x29e556[_0x28c0("0x18f")] = (function (_0x34832d) {
          var _0x57a351 = {};
          _0x57a351[_0x28c0("0x190")] = _0x34832d;
          _0x57a351[_0x28c0("0x191")] = _0x34832d;
          _0x57a351["\x64\x65\x62\x75\x67"] = _0x34832d;
          _0x57a351[_0x28c0("0x193")] = _0x34832d;
          _0x57a351[_0x28c0("0x9a")] = _0x34832d;
          _0x57a351[_0x28c0("0x194")] = _0x34832d;
          _0x57a351[_0x28c0("0x195")] = _0x34832d;
          return _0x57a351;
        })(_0x4b25e5);
      } else {
        _0x29e556[_0x28c0("0x18f")]["\x6c\x6f\x67"] = _0x4b25e5;
        _0x29e556[_0x28c0("0x18f")][_0x28c0("0x191")] = _0x4b25e5;
        _0x29e556[_0x28c0("0x18f")][_0x28c0("0x192")] = _0x4b25e5;
        _0x29e556["\x63\x6f\x6e\x73\x6f\x6c\x65"][
          "\x69\x6e\x66\x6f"
        ] = _0x4b25e5;
        _0x29e556[_0x28c0("0x18f")]["\x65\x72\x72\x6f\x72"] = _0x4b25e5;
        _0x29e556[_0x28c0("0x18f")][_0x28c0("0x194")] = _0x4b25e5;
        _0x29e556[_0x28c0("0x18f")][_0x28c0("0x195")] = _0x4b25e5;
      }
    });
    _0x157f11();
    var _0x35ec52 = videojs[_0x28c0("0x53")](_0x28c0("0x196")),
      _0x3468df =
        (videojs[_0x28c0("0x53")]("\x42\x75\x74\x74\x6f\x6e"),
        videojs[_0x28c0("0x53")](_0x28c0("0x197"))),
      _0xfff87b = videojs[_0x28c0("0x75")](_0x3468df, {
        constructor: function (_0x598db3, _0x51baa9) {
          _0x3468df[_0x28c0("0x93")](this, arguments),
            (this[_0x28c0("0x198")] = _0x51baa9[_0x28c0("0x198")] || null),
            (this[_0x28c0("0xe0")] =
              _0x51baa9["\x72\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e"] || null),
            (this["\x73\x77\x69\x74\x63\x68\x65\x72"] =
              _0x51baa9["\x73\x77\x69\x74\x63\x68\x65\x72"] || null);
        },
        handleClick: function () {
          var _0x26f16f = this[_0x28c0("0x131")];
          this[_0x28c0("0xe0")] &&
            _0x26f16f[_0x28c0("0x19a")](this[_0x28c0("0xe0")]),
            this[_0x28c0("0x198")] &&
              _0x26f16f[
                "\x73\x65\x74\x53\x75\x62\x4c\x61\x6e\x67\x75\x61\x67\x65"
              ](this[_0x28c0("0x198")]);
        },
      }),
      _0x54dbc8 = videojs[_0x28c0("0x75")](_0x35ec52, {
        constructor: function (_0x32f2d5) {
          _0x35ec52[_0x28c0("0x93")](this, arguments),
            _0x32f2d5["\x6f\x6e"](
              _0x28c0("0x19c"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x179")])
            ),
            _0x32f2d5["\x6f\x6e"](
              _0x28c0("0x17a"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
            ),
            _0x32f2d5["\x6f\x6e"](
              _0x28c0("0xf2"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
            ),
            _0x32f2d5["\x6f\x6e"](
              _0x28c0("0xf7"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x19d")])
            ),
            this["\x68\x69\x64\x65"]();
        },
      });
    (_0x54dbc8["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      "\x73\x68\x6f\x77"
    ] = function () {
      this["\x70\x6c\x61\x79\x65\x72\x5f"][
        "\x67\x65\x74\x52\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x73"
      ]() &&
      0x1 <
        this[_0x28c0("0x131")][
          "\x67\x65\x74\x52\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x73"
        ]()[_0x28c0("0x73")]
        ? _0x35ec52[_0x28c0("0xe4")][_0x28c0("0x17b")]["\x61\x70\x70\x6c\x79"](
            this
          )
        : _0x35ec52[_0x28c0("0xe4")][_0x28c0("0x179")][_0x28c0("0x93")](this);
    }),
      (_0x54dbc8[_0x28c0("0xe4")][_0x28c0("0x19f")] = function () {
        return (
          _0x28c0("0x1a0") +
          _0x35ec52[_0x28c0("0xe4")][_0x28c0("0x19f")][_0x28c0("0x1a1")](this)
        );
      }),
      (_0x54dbc8[_0x28c0("0xe4")][_0x28c0("0x1a2")] = function (_0x4dcebe) {
        _0x4dcebe = _0x4dcebe || [];
        for (
          var _0xbaac61 = this[_0x28c0("0x131")][
              "\x72\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e"
            ],
            _0x18a014 = this[_0x28c0("0x131")][
              "\x67\x65\x74\x52\x65\x73\x6f\x6c\x75\x74\x69\x6f\x6e\x73"
            ](),
            _0x53811b = 0x0;
          _0x53811b < _0x18a014[_0x28c0("0x73")];
          _0x53811b++
        ) {
          var _0x4fd8a8 = this[_0x28c0("0x131")][_0x28c0("0x97")](
            _0x28c0("0x1a3") + _0x18a014[_0x53811b]
          );
          _0x28c0("0x86") == _0x18a014[_0x53811b] &&
            _0x28c0("0x86") == _0xbaac61 &&
            null != this[_0x28c0("0x131")][_0x28c0("0x7d")] &&
            (_0x4fd8a8 +=
              _0x28c0("0x1a4") +
              this[_0x28c0("0x131")][_0x28c0("0x7d")] +
              _0x28c0("0x1a5")),
            _0x4dcebe[_0x28c0("0x6f")](
              new _0xfff87b(this[_0x28c0("0x131")], {
                label: _0x4fd8a8,
                selected: _0xbaac61 == _0x18a014[_0x53811b],
                selectable: !0x0,
                resolution: _0x18a014[_0x53811b],
              })
            );
        }
        return _0x4dcebe;
      }),
      videojs[_0x28c0("0x113")](_0x28c0("0x1a6"), _0x54dbc8);
    var _0x5dd7b0 = videojs[_0x28c0("0x75")](_0x35ec52, {
      constructor: function (_0x4eced3) {
        _0x35ec52[_0x28c0("0x93")](this, arguments),
          _0x4eced3["\x6f\x6e"](
            _0x28c0("0x19c"),
            videojs["\x62\x69\x6e\x64"](this, this[_0x28c0("0x179")])
          ),
          _0x4eced3["\x6f\x6e"](
            "\x76\x61\x73\x74\x2e\x63\x6f\x6e\x74\x65\x6e\x74\x53\x74\x61\x72\x74",
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
          ),
          _0x4eced3["\x6f\x6e"](
            "\x61\x64\x6e\x2e\x72\x65\x61\x64\x79",
            videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
          ),
          _0x4eced3["\x6f\x6e"](
            _0x28c0("0xf7"),
            videojs[_0x28c0("0x5d")](this, this["\x75\x70\x64\x61\x74\x65"])
          ),
          this[_0x28c0("0x179")]();
      },
    });
    (_0x5dd7b0["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      _0x28c0("0x17b")
    ] = function () {
      this[_0x28c0("0x131")][_0x28c0("0x1a7")]() &&
      0x1 <
        this[_0x28c0("0x131")][_0x28c0("0x1a7")]()["\x6c\x65\x6e\x67\x74\x68"]
        ? _0x35ec52[_0x28c0("0xe4")][_0x28c0("0x17b")]["\x61\x70\x70\x6c\x79"](
            this
          )
        : _0x35ec52[_0x28c0("0xe4")][_0x28c0("0x179")][_0x28c0("0x93")](this);
    }),
      (_0x5dd7b0[_0x28c0("0xe4")][
        "\x62\x75\x69\x6c\x64\x43\x53\x53\x43\x6c\x61\x73\x73"
      ] = function () {
        return (
          _0x28c0("0x1a8") +
          _0x35ec52["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
            "\x62\x75\x69\x6c\x64\x43\x53\x53\x43\x6c\x61\x73\x73"
          ][_0x28c0("0x1a1")](this)
        );
      }),
      (_0x5dd7b0[_0x28c0("0xe4")][_0x28c0("0x1a2")] = function (_0x6843ac) {
        _0x6843ac = _0x6843ac || [];
        for (
          var _0x86044f = this[_0x28c0("0x131")][_0x28c0("0xde")],
            _0x5c79d0 = this["\x70\x6c\x61\x79\x65\x72\x5f"][
              _0x28c0("0x1a7")
            ](),
            _0x9db5f3 = 0x0;
          _0x9db5f3 < _0x5c79d0["\x6c\x65\x6e\x67\x74\x68"];
          _0x9db5f3++
        )
          _0x6843ac[_0x28c0("0x6f")](
            new _0xfff87b(this["\x70\x6c\x61\x79\x65\x72\x5f"], {
              label: this["\x70\x6c\x61\x79\x65\x72\x5f"][_0x28c0("0x97")](
                _0x28c0("0x1a3") + _0x5c79d0[_0x9db5f3]
              ),
              selected: _0x86044f == _0x5c79d0[_0x9db5f3],
              selectable: !0x0,
              language: _0x5c79d0[_0x9db5f3],
            })
          );
        return _0x6843ac;
      }),
      videojs[_0x28c0("0x113")](
        "\x4c\x61\x6e\x67\x75\x61\x67\x65\x53\x77\x69\x74\x63\x68\x65\x72",
        _0x5dd7b0
      );
  })(),
  (WebVTT = !0x0),
  (function () {
    var _0x3f1933 = videojs["\x67\x65\x74\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74"](
        _0x28c0("0x177")
      ),
      _0x33d1e0 = videojs[_0x28c0("0x75")](_0x3f1933, {
        constructor: function (_0x157c6f, _0x977156) {
          _0x3f1933[_0x28c0("0x93")](this, arguments),
            (this["\x72\x65\x66\x72\x65\x73\x68\x54\x69\x6d\x65"] = 0x1e),
            this[_0x28c0("0x1aa")](),
            _0x157c6f["\x6f\x6e"](
              _0x28c0("0x1ab"),
              videojs[_0x28c0("0x5d")](this, this["\x72\x65\x73\x65\x74"])
            ),
            _0x157c6f["\x6f\x6e"](
              "\x74\x69\x6d\x65\x75\x70\x64\x61\x74\x65",
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x19d")])
            ),
            _0x157c6f["\x6f\x6e"](
              _0x28c0("0xf0"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x1ac")])
            ),
            _0x157c6f["\x6f\x6e"](
              "\x70\x6c\x61\x79",
              videojs["\x62\x69\x6e\x64"](
                this,
                this["\x6f\x6e\x50\x6c\x61\x79"]
              )
            );
        },
      });
    (_0x33d1e0[_0x28c0("0xe4")][_0x28c0("0x1aa")] = function () {
      (this[_0x28c0("0x1ad")] = 0x0),
        (this[_0x28c0("0x1ae")] = 0x0),
        (this["\x76\x69\x65\x77\x54\x69\x6d\x65"] = 0x0),
        (this[_0x28c0("0x1b0")] = 0x0),
        (this[_0x28c0("0x1b1")] = !0x1),
        (this["\x70\x61\x75\x73\x65\x54\x69\x6d\x65"] = new Date()),
        (this["\x73\x74\x61\x72\x74\x54\x69\x6d\x65"] = new Date()),
        (this[_0x28c0("0x1b3")] = new Date()),
        (this[
          "\x68\x69\x73\x74\x6f\x72\x79\x43\x72\x65\x61\x74\x69\x6f\x6e\x44\x6f\x6e\x65"
        ] = !0x1),
        (this[_0x28c0("0x1b5")] = !0x1);
    }),
      (_0x33d1e0[_0x28c0("0xe4")][_0x28c0("0x1b6")] = function () {
        this[_0x28c0("0x1ac")](),
          0x0 == this[_0x28c0("0x1b1")] &&
            ((this[_0x28c0("0x1b1")] = !0x0), this[_0x28c0("0x19d")]());
      }),
      (_0x33d1e0[_0x28c0("0xe4")]["\x75\x70\x64\x61\x74\x65"] = function () {
        if (this["\x63\x61\x6e\x55\x70\x64\x61\x74\x65\x56\x69\x65\x77"]())
          return (
            (this[_0x28c0("0x1b5")] = !0x0),
            this[_0x28c0("0xc1")](_0x28c0("0x1b8"))
          );
        if (this["\x6e\x65\x65\x64\x55\x70\x64\x61\x74\x65"]()) {
          if (!0x1 === this[_0x28c0("0x1b4")])
            return (
              (this[_0x28c0("0x1b4")] = !0x0),
              this["\x73\x65\x6e\x64"](_0x28c0("0x1ba"))
            );
          (this[_0x28c0("0x1b3")] = new Date()),
            (this[_0x28c0("0x1af")] =
              this[_0x28c0("0x1b3")][_0x28c0("0x65")]() / 0x3e8 -
              this[_0x28c0("0x63")][_0x28c0("0x65")]() / 0x3e8 -
              this[_0x28c0("0x1b0")]),
            this[_0x28c0("0xc1")](_0x28c0("0x1bb"));
        }
      }),
      (_0x33d1e0[_0x28c0("0xe4")][_0x28c0("0xc1")] = function (_0x273960) {
        var _0x25510c = new XMLHttpRequest(),
          _0xcc313e = new FormData(),
          _0x32a418 = this[_0x28c0("0x131")][_0x28c0("0x1bc")](),
          _0x306233 = _0x32a418["\x75\x70\x64\x61\x74\x65"];
        "\x75\x70\x64\x61\x74\x65\x76\x69\x65\x77" === _0x273960
          ? (_0x306233 = _0x32a418[_0x28c0("0x1b5")])
          : "\x63\x72\x65\x61\x74\x65\x68\x69\x73\x74\x6f\x72\x79" === _0x273960
          ? (_0x306233 = _0x32a418[_0x28c0("0x1bd")])
          : (_0xcc313e[_0x28c0("0x1be")](
              _0x28c0("0x198"),
              this["\x70\x6c\x61\x79\x65\x72\x5f"][_0x28c0("0xde")] ||
                "\x75\x6e\x6b\x6e\x6f\x77\x6e"
            ),
            _0xcc313e["\x61\x70\x70\x65\x6e\x64"](
              _0x28c0("0x1bf"),
              this[_0x28c0("0x131")][_0x28c0("0xe0")] || _0x28c0("0x1c0")
            ),
            _0xcc313e[_0x28c0("0x1be")](
              "\x76\x69\x65\x77\x74\x69\x6d\x65",
              Math[_0x28c0("0x13f")](this[_0x28c0("0x1af")])
            ),
            _0xcc313e[_0x28c0("0x1be")](
              _0x28c0("0x1c1"),
              Math[_0x28c0("0x13f")](this[_0x28c0("0x1ae")])
            ),
            _0xcc313e[_0x28c0("0x1be")](
              _0x28c0("0x1ad"),
              Math["\x72\x6f\x75\x6e\x64"](this[_0x28c0("0x1ad")])
            ),
            _0xcc313e[_0x28c0("0x1be")](_0x28c0("0x1c2"), _0x28c0("0x1c3")));
        try {
          _0x25510c["\x6f\x70\x65\x6e"](_0x28c0("0x1c4"), _0x306233, !0x0),
            _0x25510c[_0x28c0("0xac")](_0x28c0("0xb9"), function () {}),
            _0x25510c[_0x28c0("0xbf")](
              "\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e",
              _0x28c0("0xc0") +
                this[_0x28c0("0x131")][
                  "\x67\x65\x74\x41\x63\x63\x65\x73\x73\x54\x6f\x6b\x65\x6e"
                ]()
            ),
            _0x25510c[_0x28c0("0xc1")](_0xcc313e);
        } catch (_0x3a2fbd) {}
      }),
      (_0x33d1e0[_0x28c0("0xe4")][_0x28c0("0x1b9")] = function () {
        if (0x0 == this[_0x28c0("0x1b1")]) return !0x1;
        if (0x0 == this[_0x28c0("0x1b4")]) return !0x0;
        var _0x2f8b63 = this[_0x28c0("0x131")][_0x28c0("0x1ad")]();
        if (this[_0x28c0("0x1ad")] != _0x2f8b63) {
          if (!(0x0 < _0x2f8b63)) return !0x1;
          this[_0x28c0("0x1ad")] = _0x2f8b63;
        }
        return (
          (this[_0x28c0("0x1ae")] = this[_0x28c0("0x131")][_0x28c0("0x61")]()),
          new Date()[_0x28c0("0x65")]() / 0x3e8 >=
            this[_0x28c0("0x1a9")] +
              this[_0x28c0("0x1b3")][_0x28c0("0x65")]() / 0x3e8
        );
      }),
      (_0x33d1e0[_0x28c0("0xe4")][_0x28c0("0x1ac")] = function () {
        if (this["\x70\x6c\x61\x79\x65\x72\x5f"][_0x28c0("0x153")]())
          this["\x70\x61\x75\x73\x65\x54\x69\x6d\x65"] = new Date();
        else {
          var _0x198328 = new Date();
          this["\x77\x61\x69\x74\x54\x69\x6d\x65"] +=
            _0x198328[_0x28c0("0x65")]() / 0x3e8 -
            this[_0x28c0("0x1b2")][_0x28c0("0x65")]() / 0x3e8;
        }
      }),
      (_0x33d1e0["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
        _0x28c0("0x1b7")
      ] = function () {
        return (
          !0x0 !== this[_0x28c0("0x1b5")] &&
          void 0x0 !==
            this[_0x28c0("0x131")][_0x28c0("0x1bc")]()[_0x28c0("0x1b5")] &&
          0x0 !== this[_0x28c0("0x1ad")] &&
          0.75 <=
            this["\x73\x74\x6f\x70\x54\x69\x6d\x65"] / this[_0x28c0("0x1ad")]
        );
      }),
      videojs[_0x28c0("0x113")](_0x28c0("0x1c6"), _0x33d1e0);
  })(),
  (function () {
    var _0x46eaff = videojs[_0x28c0("0x53")](_0x28c0("0x177")),
      _0x3eae44 = videojs[_0x28c0("0x75")](_0x46eaff, {
        constructor: function (_0x420313, _0x19e56c) {
          _0x46eaff[_0x28c0("0x93")](this, arguments),
            (this["\x6f\x70\x74\x69\x6f\x6e\x73"] = _0x19e56c || []),
            _0x420313["\x6f\x6e"](
              _0x28c0("0x19c"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x179")])
            ),
            _0x420313["\x6f\x6e"](
              _0x28c0("0x17a"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
            ),
            _0x420313["\x6f\x6e"](
              _0x28c0("0x17c"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
            ),
            this["\x63\x72\x65\x61\x74\x65\x44\x6f\x63\x6b\x45\x6c"](_0x420313);
        },
      });
    (_0x3eae44[_0x28c0("0xe4")][_0x28c0("0x129")] = function () {
      var _0x29fea9 = document[_0x28c0("0xc")](_0x28c0("0x20"));
      return (
        (_0x29fea9["\x63\x6c\x61\x73\x73\x4e\x61\x6d\x65"] = _0x28c0("0x1c9")),
        (this[_0x28c0("0x1ca")] = document[_0x28c0("0xc")]("\x75\x6c")),
        (this["\x6c\x69\x73\x74"][_0x28c0("0xd")] = _0x28c0("0x1cb")),
        _0x29fea9[_0x28c0("0x11")](this[_0x28c0("0x1ca")]),
        _0x29fea9
      );
    }),
      (_0x3eae44[_0x28c0("0xe4")][_0x28c0("0x1c8")] = function (_0xf10475) {
        if (
          0x0 !=
          this["\x6f\x70\x74\x69\x6f\x6e\x73"]["\x6c\x65\x6e\x67\x74\x68"]
        )
          for (
            var _0x47caf9 = 0x0;
            _0x47caf9 < this["\x6f\x70\x74\x69\x6f\x6e\x73"][_0x28c0("0x73")];
            _0x47caf9++
          ) {
            var _0x2395b1 = document[
              "\x63\x72\x65\x61\x74\x65\x45\x6c\x65\x6d\x65\x6e\x74"
            ]("\x6c\x69");
            (_0x2395b1["\x63\x6c\x61\x73\x73\x4e\x61\x6d\x65"] =
              "\x76\x6a\x73\x2d\x64\x6f\x63\x6b\x2d\x65\x6c\x65\x6d\x65\x6e\x74"),
              (_0x2395b1["\x69\x6e\x6e\x65\x72\x48\x54\x4d\x4c"] =
                _0x28c0("0x1cc") +
                this[_0x28c0("0x1c7")][_0x47caf9][_0x28c0("0x1cd")] +
                _0x28c0("0x1ce") +
                this["\x6f\x70\x74\x69\x6f\x6e\x73"][_0x47caf9][
                  _0x28c0("0x17d")
                ] +
                _0x28c0("0x1cf")),
              this[_0x28c0("0x1ca")][
                "\x61\x70\x70\x65\x6e\x64\x43\x68\x69\x6c\x64"
              ](_0x2395b1),
              _0x2395b1[
                "\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"
              ](_0x28c0("0xaf"), function () {
                _0xf10475[_0x28c0("0xf0")]();
              });
          }
      }),
      videojs[_0x28c0("0x113")]("\x44\x6f\x63\x6b", _0x3eae44);
  })(),
  (function () {
    var _0x281da1 = videojs[_0x28c0("0x53")](_0x28c0("0x177")),
      _0x5e4c41 = videojs["\x67\x65\x74\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74"](
        _0x28c0("0x1d0")
      ),
      _0x28c428 = videojs[_0x28c0("0x75")](_0x5e4c41, {
        constructor: function (_0x364724, _0x1dc3b3) {
          _0x5e4c41[_0x28c0("0x93")](this, arguments),
            _0x364724["\x6f\x6e"](
              _0x28c0("0xc9"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
            ),
            this[_0x28c0("0x1d1")](
              "\x50\x6c\x61\x79\x20\x6e\x65\x78\x74\x20\x76\x69\x64\x65\x6f"
            ),
            this[_0x28c0("0x179")]();
        },
        handleClick: function () {
          this[_0x28c0("0x131")][_0x28c0("0xa2")]();
        },
        buildCSSClass: function () {
          return (
            _0x28c0("0x1d2") +
            _0x5e4c41["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][_0x28c0("0x19f")][
              _0x28c0("0x1a1")
            ](this)
          );
        },
        show: function () {
          null ==
            this[_0x28c0("0x131")][
              "\x67\x65\x74\x4e\x65\x78\x74\x56\x69\x64\x65\x6f\x55\x72\x6c"
            ]() ||
          this[_0x28c0("0x131")][
            "\x67\x65\x74\x41\x64\x73\x45\x6e\x61\x62\x6c\x65\x64"
          ]()
            ? _0x5e4c41["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
                _0x28c0("0x179")
              ][_0x28c0("0x93")](this)
            : _0x5e4c41["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
                _0x28c0("0x17b")
              ][_0x28c0("0x93")](this);
        },
      }),
      _0x4fa084 = videojs[_0x28c0("0x75")](_0x5e4c41, {
        constructor: function (_0x22b1d9, _0x508129) {
          _0x5e4c41["\x61\x70\x70\x6c\x79"](this, arguments),
            _0x22b1d9["\x6f\x6e"](
              _0x28c0("0xca"),
              videojs[_0x28c0("0x5d")](this, this[_0x28c0("0x17b")])
            ),
            this[_0x28c0("0x1d1")](_0x28c0("0x1d5")),
            this["\x68\x69\x64\x65"]();
        },
        handleClick: function () {
          this["\x70\x6c\x61\x79\x65\x72\x5f"][_0x28c0("0x1d6")]();
        },
        buildCSSClass: function () {
          return (
            _0x28c0("0x1d7") +
            _0x5e4c41[_0x28c0("0xe4")][_0x28c0("0x19f")][_0x28c0("0x1a1")](this)
          );
        },
        show: function () {
          null == this[_0x28c0("0x131")][_0x28c0("0x1d8")]() ||
          this[_0x28c0("0x131")][
            "\x67\x65\x74\x41\x64\x73\x45\x6e\x61\x62\x6c\x65\x64"
          ]()
            ? _0x5e4c41[_0x28c0("0xe4")]["\x68\x69\x64\x65"][
                "\x61\x70\x70\x6c\x79"
              ](this)
            : _0x5e4c41[_0x28c0("0xe4")]["\x73\x68\x6f\x77"][_0x28c0("0x93")](
                this
              );
        },
      }),
      _0x4f49ae = videojs[_0x28c0("0x75")](_0x281da1, {
        constructor: function (_0x2e905b, _0x2a4db7) {
          _0x281da1[_0x28c0("0x93")](this, arguments),
            (this[_0x28c0("0x1c7")] = _0x2a4db7 || []),
            (this[_0x28c0("0x1b3")] = new Date()),
            (this[_0x28c0("0x1d9")] =
              this[_0x28c0("0x1c7")][
                "\x63\x6f\x75\x6e\x74\x64\x6f\x77\x6e\x44\x75\x72\x61\x74\x69\x6f\x6e"
              ] || 0x14),
            (this[_0x28c0("0x1da")] = null),
            this[_0x28c0("0x1db")](),
            _0x2e905b["\x6f\x6e"](
              _0x28c0("0x1dc"),
              videojs["\x62\x69\x6e\x64"](this, this[_0x28c0("0x1dd")])
            ),
            this[_0x28c0("0x179")]();
        },
      });
    (_0x4f49ae["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
      _0x28c0("0x129")
    ] = function () {
      var _0x2c3b28 = document[_0x28c0("0xc")](_0x28c0("0x20"));
      return (
        (_0x2c3b28[_0x28c0("0xd")] = _0x28c0("0x1de")),
        (this[_0x28c0("0x1ca")] = document[_0x28c0("0xc")]("\x75\x6c")),
        (this["\x6c\x69\x73\x74"][_0x28c0("0xd")] = _0x28c0("0x1cb")),
        _0x2c3b28[_0x28c0("0x11")](this[_0x28c0("0x1ca")]),
        _0x2c3b28
      );
    }),
      (_0x4f49ae["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"][
        _0x28c0("0x1db")
      ] = function () {
        (this[_0x28c0("0x1da")] = document[_0x28c0("0xc")]("\x6c\x69")),
          (this[_0x28c0("0x1da")][_0x28c0("0xd")] = _0x28c0("0x1df")),
          (this["\x62\x75\x74\x74\x6f\x6e\x45\x6c"][_0x28c0("0xf")] = _0x28c0(
            "0x1e0"
          )),
          this[_0x28c0("0x1ca")][_0x28c0("0x11")](this[_0x28c0("0x1da")]);
        var _0x5f5582 = this;
        this["\x62\x75\x74\x74\x6f\x6e\x45\x6c"][_0x28c0("0xac")](
          "\x63\x6c\x69\x63\x6b",
          function (_0x2892f5) {
            _0x2892f5[_0x28c0("0x164")](),
              _0x5f5582[_0x28c0("0x131")][_0x28c0("0xa2")](),
              _0x5f5582["\x68\x69\x64\x65"]();
          }
        );
      }),
      (_0x4f49ae[_0x28c0("0xe4")][_0x28c0("0x1dd")] = function () {
        var _0x3a7148 = this[_0x28c0("0x131")][_0x28c0("0x1ad")]();
        if (0x0 !== _0x3a7148) {
          var _0xd9cf = this[_0x28c0("0x131")][_0x28c0("0x61")]();
          new Date()[_0x28c0("0x65")]() / 0x3e8 <
            0.5 + this[_0x28c0("0x1b3")][_0x28c0("0x65")]() / 0x3e8 ||
            ((this[_0x28c0("0x1b3")] = new Date()),
            null != this[_0x28c0("0x131")][_0x28c0("0x1d3")]()
              ? this[_0x28c0("0x131")][
                  "\x67\x65\x74\x41\x64\x73\x45\x6e\x61\x62\x6c\x65\x64"
                ]()
                ? this[_0x28c0("0x179")]()
                : this[_0x28c0("0x131")][_0x28c0("0x1e1")]() &&
                  0x0 < _0xd9cf &&
                  _0xd9cf + this[_0x28c0("0x1d9")] + 0.5 >= _0x3a7148
                ? this[_0x28c0("0x1e2")](_0x3a7148 - _0xd9cf)
                : this["\x68\x69\x64\x65"]()
              : this[_0x28c0("0x179")]());
        }
      }),
      (_0x4f49ae[_0x28c0("0xe4")][_0x28c0("0x1e2")] = function (_0x3b3edc) {
        this[_0x28c0("0x17b")](),
          (this["\x62\x75\x74\x74\x6f\x6e\x45\x6c"][_0x28c0("0x1e4")](
            _0x28c0("0x12f")
          )[0x0][_0x28c0("0x1e3")] =
            this[_0x28c0("0x131")][_0x28c0("0x97")](_0x28c0("0x1e5")) +
            "\x20" +
            Math[_0x28c0("0x13f")](_0x3b3edc) +
            "\x73");
      }),
      videojs[_0x28c0("0x113")](
        "\x4e\x65\x78\x74\x56\x69\x64\x65\x6f\x43\x6f\x75\x6e\x74\x64\x6f\x77\x6e",
        _0x4f49ae
      ),
      videojs[_0x28c0("0x113")](_0x28c0("0x1e6"), _0x4fa084),
      videojs[
        "\x72\x65\x67\x69\x73\x74\x65\x72\x43\x6f\x6d\x70\x6f\x6e\x65\x6e\x74"
      ](_0x28c0("0x1e7"), _0x28c428);
  })();
